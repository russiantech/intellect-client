export { Instructors as default } from './AllSharedPages';
