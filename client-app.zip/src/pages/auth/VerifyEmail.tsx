// VerifyEmail.tsx
import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { authApi } from '@/services/api';

export function VerifyEmail() {
  const [params] = useSearchParams();
  const token = params.get('token') || '';
  const [status, setStatus] = useState<'verifying' | 'success' | 'error'>('verifying');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (!token) { setStatus('error'); setMsg('Invalid verification link'); return; }
    authApi.verifyEmail(token)
      .then(r => { setStatus('success'); setMsg(r.data.message); })
      .catch(e => { setStatus('error'); setMsg(e.response?.data?.detail || 'Verification failed'); });
  }, [token]);

  return (
    <div className="auth-layout">
      <div className="auth-left">
        <div style={{ position: 'relative', zIndex: 1 }}>
          <h5 className="display-3 text-white fw-bold mb-4" style={{ fontFamily: 'var(--font-heading)', fontSize: '2.5rem' }}>Intellect</h5>
          <p className="text-white opacity-75">Your Digital Learning Companion</p>
        </div>
      </div>
      <div className="auth-right">
        <div className="text-center">
          {status === 'verifying' && (
            <>
              <div className="spinner-border text-primary mb-4" style={{ width: 48, height: 48 }} />
              <h5>Verifying your email…</h5>
            </>
          )}
          {status === 'success' && (
            <>
              <div style={{ width: 80, height: 80, borderRadius: '50%', background: '#d1fae5', margin: '0 auto 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="bi bi-check-circle text-success" style={{ fontSize: '2.5rem' }} />
              </div>
              <h4 className="fw-bold mb-2">Email Verified!</h4>
              <p className="text-muted mb-4" style={{ fontSize: '0.875rem' }}>{msg}</p>
              <Link to="/auth/signin" className="btn btn-primary w-100 py-2">Continue to Sign In</Link>
            </>
          )}
          {status === 'error' && (
            <>
              <div style={{ width: 80, height: 80, borderRadius: '50%', background: '#fee2e2', margin: '0 auto 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <i className="bi bi-x-circle text-danger" style={{ fontSize: '2.5rem' }} />
              </div>
              <h4 className="fw-bold mb-2">Verification Failed</h4>
              <p className="text-muted mb-4" style={{ fontSize: '0.875rem' }}>{msg}</p>
              <Link to="/auth/signin" className="btn btn-outline-primary w-100 py-2">Go to Sign In</Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default VerifyEmail;
