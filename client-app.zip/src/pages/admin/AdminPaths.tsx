export { default } from './AdminPathsPage';
