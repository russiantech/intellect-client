import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { coursesApi, adminApi } from '@/services/api';
import { Course } from '@/types';
import { Spinner, Empty, Modal, StatusBadge, PageTitle, SearchInput, Avatar } from '@/components/shared';
import { CourseThumbnail } from '@/components/shared/CourseThumbnail';

export default function AdminCourses() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [approvalModal, setApprovalModal] = useState<{ course: Course | null; show: boolean }>({ course: null, show: false });
  const [rejectionReason, setRejectionReason] = useState('');
  const [processing, setProcessing] = useState(false);

  const PER_PAGE = 15;

  const load = () => {
    setLoading(true);
    const params: any = { page, per_page: PER_PAGE };
    if (search) params.search = search;
    if (status) params.status = status;
    else params.status = undefined;
    coursesApi.list(params)
      .then(r => { setCourses(r.data.items || []); setTotal(r.data.total || 0); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [page, search, status]);

  const handleApprove = async (approved: boolean) => {
    if (!approvalModal.course) return;
    if (!approved && !rejectionReason) return toast.error('Please provide a rejection reason');
    setProcessing(true);
    try {
      await coursesApi.approve(approvalModal.course.id, { approved, rejection_reason: rejectionReason || undefined });
      toast.success(`Course ${approved ? 'approved' : 'rejected'}`);
      setApprovalModal({ course: null, show: false });
      setRejectionReason('');
      load();
    } catch (err: any) { toast.error(err.response?.data?.detail || 'Action failed'); }
    finally { setProcessing(false); }
  };

  const handleDelete = async (course: Course) => {
    if (!confirm(`Delete "${course.title}"? This cannot be undone.`)) return;
    try {
      await coursesApi.delete(course.id);
      toast.success('Course deleted');
      load();
    } catch { toast.error('Delete failed'); }
  };

  const pages = Math.ceil(total / PER_PAGE);

  // Reusable thumbnail component
  /*
  const CourseThumbnail = ({ thumbnail, size = 48 }: { thumbnail?: string; size?: number }) => {
    const [error, setError] = useState(false);
    
    if (!thumbnail || error) {
      return (
        <div style={{ 
          width: size, 
          height: size * 0.75, 
          borderRadius: 6, 
          background: 'var(--primary-light)', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center', 
          flexShrink: 0 
        }}>
          <i className="bi bi-play-circle text-primary" />
        </div>
      );
    }
    
    return (
      <img 
        src={`/uploads/courses/thumbnails/${thumbnail}`} 
        alt="" 
        onError={() => setError(true)}
        style={{ width: size, height: size * 0.75, borderRadius: 6, objectFit: 'cover', flexShrink: 0 }} 
      />
    );
  }
*/
  return (
    <div className="fade-in">
      <PageTitle title="Manage Courses" subtitle="Review, approve, and manage all courses" crumbs={[{ label: 'Admin' }, { label: 'Courses' }]} />

      {/* Filters */}
      <div className="card mb-4">
        <div className="p-3 d-flex flex-wrap gap-3 align-items-center">
          <div style={{ flex: '1 1 260px' }}>
            <SearchInput value={search} onChange={v => { setSearch(v); setPage(1); }} placeholder="Search courses…" />
          </div>
          <select className="form-select" style={{ width: 'auto' }} value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}>
            <option value="">All Statuses</option>
            {['draft','pending','published','unpublished','rejected'].map(s => <option key={s} value={s} style={{ textTransform: 'capitalize' }}>{s}</option>)}
          </select>
          <span className="text-muted" style={{ fontSize: '0.8rem' }}>{total} course{total !== 1 ? 's' : ''}</span>
        </div>
      </div>

      {loading ? <Spinner /> : courses.length === 0 ? <Empty icon="bi-journal-x" title="No courses found" /> : (
        <>
          <div className="card overflow-hidden">
            <div className="table-responsive">
              <table className="table mb-0">
                <thead>
                  <tr>
                    <th>Course</th>
                    <th>Creator</th>
                    <th>Level</th>
                    <th>Fee</th>
                    <th>Enrolled</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {courses.map(c => (
                    <tr key={c.id}>
                      <td style={{ maxWidth: 280 }}>
                      <div className="d-flex align-items-center gap-3">
                        <CourseThumbnail thumbnail={c.thumbnail} size={48} borderRadius={6} />
                        <div>
                          <Link to={`/courses/${c.slug}`} className="fw-600 text-decoration-none" style={{ fontSize: '0.875rem', display: 'block' }}>{c.title}</Link>
                          <span className="text-muted" style={{ fontSize: '0.72rem' }}>{c.lessons_count} lessons · {c.created_at ? new Date(c.created_at).toLocaleDateString() : ''}</span>
                        </div>
                      </div>
                    </td>
                      <td>
                        {c.creator ? (
                          <div className="d-flex align-items-center gap-2">
                            <Avatar image={c.creator.image} name={c.creator.name} size={28} />
                            <span style={{ fontSize: '0.8rem' }}>{c.creator.name}</span>
                          </div>
                        ) : <span className="text-muted">—</span>}
                      </td>
                      <td><span className={`badge-level ${c.level}`}>{c.level}</span></td>
                      <td style={{ fontSize: '0.875rem' }}>
                        {c.fee > 0 ? `₦${c.fee.toLocaleString()}` : <span className="text-success fw-600">Free</span>}
                      </td>
                      <td style={{ fontSize: '0.875rem' }}>{c.enrolled_count}</td>
                      <td><StatusBadge status={c.status} /></td>
                      <td>
                        <div className="d-flex gap-1">
                          {c.status === 'pending' && (
                            <button className="btn btn-sm btn-success btn-icon-start" onClick={() => { setApprovalModal({ course: c, show: true }); setRejectionReason(''); }}>
                              <i className="bi bi-check-circle" /> Review
                            </button>
                          )}
                          <Link to={`/admin/courses/${c.id}/revenue`} className="btn btn-sm btn-outline-warning" title="Configure revenue split"><i className="bi bi-percent" /></Link>
                          <Link to={`/courses/${c.slug}`} className="btn btn-sm btn-outline-secondary"><i className="bi bi-eye" /></Link>
                          <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(c)}><i className="bi bi-trash" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {pages > 1 && (
            <nav className="mt-3">
              <ul className="pagination justify-content-center">
                <li className={`page-item ${page === 1 ? 'disabled' : ''}`}><button className="page-link" onClick={() => setPage(p => p - 1)}><i className="bi bi-chevron-left" /></button></li>
                {Array.from({ length: Math.min(pages, 7) }, (_, i) => i + 1).map(p => (
                  <li key={p} className={`page-item ${page === p ? 'active' : ''}`}><button className="page-link" onClick={() => setPage(p)}>{p}</button></li>
                ))}
                <li className={`page-item ${page === pages ? 'disabled' : ''}`}><button className="page-link" onClick={() => setPage(p => p + 1)}><i className="bi bi-chevron-right" /></button></li>
              </ul>
            </nav>
          )}
        </>
      )}

      {/* Approval Modal */}
      <Modal show={approvalModal.show} onClose={() => setApprovalModal({ course: null, show: false })} title="Review Course" size="lg"
        footer={
          <div className="d-flex gap-2 ms-auto">
            <button className="btn btn-outline-secondary" onClick={() => setApprovalModal({ course: null, show: false })}>Cancel</button>
            <button className="btn btn-danger" disabled={processing} onClick={() => handleApprove(false)}>
              {processing ? <span className="spinner-border spinner-border-sm me-1" /> : <i className="bi bi-x-circle me-1" />}Reject
            </button>
            <button className="btn btn-success" disabled={processing} onClick={() => handleApprove(true)}>
              {processing ? <span className="spinner-border spinner-border-sm me-1" /> : <i className="bi bi-check-circle me-1" />}Approve & Publish
            </button>
          </div>
        }>
        {approvalModal.course && (
          <div>
            <div className="d-flex align-items-start gap-3 mb-4">
              {approvalModal.course.thumbnail && <img src={`/uploads/courses/thumbnails/${approvalModal.course.thumbnail}`} alt="" style={{ width: 100, height: 68, objectFit: 'cover', borderRadius: 8 }} />}
              <div>
                <h5 className="fw-700 mb-1">{approvalModal.course.title}</h5>
                <p className="text-muted mb-1" style={{ fontSize: '0.8rem' }}>{approvalModal.course.short_description}</p>
                <div className="d-flex gap-2 flex-wrap">
                  <span className={`badge-level ${approvalModal.course.level}`}>{approvalModal.course.level}</span>
                  <span className="text-muted" style={{ fontSize: '0.75rem' }}>{approvalModal.course.lessons_count} lessons</span>
                  {approvalModal.course.fee > 0 ? <span className="fw-600 text-primary" style={{ fontSize: '0.8rem' }}>₦{approvalModal.course.fee.toLocaleString()}</span> : <span className="text-success" style={{ fontSize: '0.8rem' }}>Free</span>}
                </div>
              </div>
            </div>
            <div>
              <label className="form-label fw-600">Rejection Reason (required if rejecting)</label>
              <textarea className="form-control" rows={3} placeholder="Provide clear feedback for the creator…" value={rejectionReason} onChange={e => setRejectionReason(e.target.value)} />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
