export { default } from './AdminSchedulesPage';
