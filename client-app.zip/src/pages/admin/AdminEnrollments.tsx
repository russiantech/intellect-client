export { default } from './AdminEnrollmentsPage';
