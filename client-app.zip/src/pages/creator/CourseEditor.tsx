import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { coursesApi } from '@/services/api';
import { Course, Category, Tag } from '@/types';
import { Spinner, PageTitle } from '@/components/shared';

/* ─── Constants ─────────────────────────────────────────── */
const STEPS = ['Details', 'Curriculum', 'Media', 'Pricing', 'Publish'];
const LEVELS = ['novice', 'beginner', 'intermediate', 'professional', 'expert', 'advanced'];
const PAYMENT_TYPES = [
  { value: 'free',          label: 'Free' },
  { value: 'one_time',      label: 'One-time Payment' },
  { value: 'subscription',  label: 'Subscription' },
  { value: 'pay_as_you_go', label: 'Pay as You Go' },
];

/* ─── Types ──────────────────────────────────────────────── */
interface Details {
  title: string; short_description: string; description: string;
  lang: string; level: string; duration_weeks: string;
  requirements: string; what_you_learn: string;
  category_ids: number[]; tag_ids: number[];
}
interface Pricing {
  fee: number; payment_type: string; subscription_interval: string;
}
interface TopicContent {
  id: number;
  title: string;
  content_type: string;
  file_path?: string;
  url?: string;
  body?: string;
  mime_type?: string;
  order_index: number;
}
interface TopicFormState {
  [topicId: number]: {
    showTextEditor: boolean;
    textTitle: string;
    textBody: string;
    savingText: boolean;
  };
}

/* ─── Helpers ────────────────────────────────────────────── */
/**
 * Resolve any path the backend returns to a full absolute URL.
 * Backend stores bare filenames like "abc123.png"; the API config
 * supplies the origin so the browser can fetch from any environment.
 */
function mediaUrl(path: string | null | undefined, folder = 'courses/thumbnails'): string | undefined {
  if (!path) return undefined;
  if (path.startsWith('http')) return path;
  const base = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '');
  if (path.startsWith('/')) return `${base}${path}`;
  return `${base}/uploads/${folder}/${path}`;
}

const CONTENT_ICONS: Record<string, string> = {
  video: 'bi-camera-video',
  pdf:   'bi-file-pdf',
  audio: 'bi-music-note-beamed',
  image: 'bi-image',
  ppt:   'bi-file-slides',
  text:  'bi-file-text',
  doc:   'bi-file-earmark',
};

/* ═══════════════════════════════════════════════════════════
   Drag-and-drop reorder hook
   ═══════════════════════════════════════════════════════════ */
function useDragReorder<T extends { id: number; order_index: number }>(
  items: T[],
  onReorder: (reordered: T[]) => void,
) {
  const dragSrc = useRef<number | null>(null);

  const handleDragStart = (idx: number) => { dragSrc.current = idx; };
  const handleDragOver  = (e: React.DragEvent) => e.preventDefault();
  const handleDrop      = (idx: number) => {
    if (dragSrc.current === null || dragSrc.current === idx) return;
    const next = [...items];
    const [moved] = next.splice(dragSrc.current, 1);
    next.splice(idx, 0, moved);
    onReorder(next.map((item, i) => ({ ...item, order_index: i })));
    dragSrc.current = null;
  };

  return { handleDragStart, handleDragOver, handleDrop };
}

/* ═══════════════════════════════════════════════════════════
   CourseEditor
   ═══════════════════════════════════════════════════════════ */
export default function CourseEditor() {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  /* ── Step state ── */
  const [step, setStep] = useState(0);

  /* ── Remote data ── */
  const [course,     setCourse]     = useState<Course | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags,       setTags]       = useState<Tag[]>([]);
  const [loading,    setLoading]    = useState(isEdit);
  const [saving,     setSaving]     = useState(false);

  /* ── Form state ── */
  const [details, setDetails] = useState<Details>({
    title: '', short_description: '', description: '', lang: 'en',
    level: 'beginner', duration_weeks: '', requirements: '', what_you_learn: '',
    category_ids: [], tag_ids: [],
  });
  const [pricing, setPricing] = useState<Pricing>({
    fee: 0, payment_type: 'one_time', subscription_interval: '',
  });

  /* ── Media state ── */
  const [thumbnailPreview, setThumbnailPreview] = useState('');
  const thumbRef = useRef<HTMLInputElement>(null);

  /* ── Curriculum state ── */
  const [newLessonTitle,   setNewLessonTitle]   = useState('');
  const [newTopicTitles,   setNewTopicTitles]   = useState<Record<number, string>>({});
  const [activeLesson,     setActiveLesson]     = useState<number | null>(null);
  const [uploadingContent, setUploadingContent] = useState<number | null>(null);
  const [deletingContent,  setDeletingContent]  = useState<number | null>(null);
  const [topicContents,    setTopicContents]    = useState<Record<number, TopicContent[]>>({});
  const [topicForms,       setTopicForms]       = useState<TopicFormState>({});
  const [togglingPreview,  setTogglingPreview]  = useState<number | null>(null);

  /* ── Bootstrap ── */
  useEffect(() => {
    Promise.all([
      coursesApi.getCategories(),
      coursesApi.getTags?.() ?? Promise.resolve({ data: [] }),
    ]).then(([catRes, tagRes]) => {
      setCategories(catRes.data || []);
      setTags(tagRes.data || []);
    });
  }, []);

  useEffect(() => {
    if (!isEdit || !id) return;
    coursesApi.get(id).then(r => {
      const c: Course = r.data;
      setCourse(c);
      setDetails({
        title:             c.title             || '',
        short_description: c.short_description || '',
        description:       c.description       || '',
        lang:              c.lang              || 'en',
        level:             c.level             || 'beginner',
        duration_weeks:    c.duration_weeks?.toString() || '',
        requirements:      c.requirements      || '',
        what_you_learn:    c.what_you_learn    || '',
        category_ids:      (c.categories || []).map((x: any) => x.id),
        tag_ids:           (c.tags       || []).map((x: any) => x.id),
      });
      setPricing({
        fee:                   c.fee                   ?? 0,
        payment_type:          c.payment_type          || 'one_time',
        subscription_interval: c.subscription_interval || '',
      });
      if (c.thumbnail) setThumbnailPreview(mediaUrl(c.thumbnail) ?? '');
    }).finally(() => setLoading(false));
  }, [id]);

  /* ── Tab navigation ── */
  const goToStep = useCallback((i: number) => {
    if (!isEdit && !course && i > 0) {
      toast.error('Please save course details first.');
      return;
    }
    setStep(i);
  }, [isEdit, course]);

  /* ── Save details / pricing ── */
  const saveCourse = async (redirectStep?: number) => {
    if (!details.title.trim()) { toast.error('Title is required'); return; }
    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        ...details,
        fee:            pricing.fee,
        payment_type:   pricing.payment_type,
        duration_weeks: details.duration_weeks ? Number(details.duration_weeks) : undefined,
        ...(pricing.payment_type === 'subscription' && pricing.subscription_interval
          ? { subscription_interval: pricing.subscription_interval }
          : {}),
      };
      Object.keys(payload).forEach(k => { if (payload[k] === '') delete payload[k]; });

      if (isEdit && id) {
        const r = await coursesApi.update(Number(id), payload);
        setCourse(r.data);
        toast.success('Saved!');
      } else {
        const r = await coursesApi.create(payload);
        setCourse(r.data);
        navigate(`/creator/courses/${r.data.id}/edit`, { replace: true });
        toast.success('Course created!');
      }
      if (redirectStep !== undefined) setStep(redirectStep);
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  /* ── Thumbnail upload ── */
  const uploadThumbnail = async (file: File) => {
    if (!course) { toast.error('Save course details first'); return; }
    try {
      const r = await coursesApi.uploadThumbnail(course.id, file);
      // Backend now returns absolute URL directly
      setThumbnailPreview(r.data.url ?? mediaUrl(r.data.thumbnail) ?? '');
      toast.success('Thumbnail uploaded!');
    } catch { toast.error('Thumbnail upload failed'); }
  };

  /* ── Lessons ── */
  const addLesson = async () => {
    if (!newLessonTitle.trim() || !course) return;
    try {
      const r = await coursesApi.createLesson(course.id, {
        title: newLessonTitle,
        order_index: course.lessons?.length ?? 0,
      });
      setCourse(prev => prev
        ? { ...prev, lessons: [...(prev.lessons || []), { ...r.data, topics: [] }] }
        : prev);
      setNewLessonTitle('');
      toast.success('Lesson added!');
    } catch { toast.error('Failed to add lesson'); }
  };

  const deleteLesson = async (lessonId: number) => {
    if (!course || !window.confirm('Delete this lesson and all its topics?')) return;
    try {
      await coursesApi.deleteLesson(course.id, lessonId);
      setCourse(prev => prev
        ? { ...prev, lessons: prev.lessons.filter(l => l.id !== lessonId) }
        : prev);
      toast.success('Lesson deleted');
    } catch { toast.error('Failed to delete lesson'); }
  };

  /**
   * Persist a new lesson order after drag-and-drop.
   * Calls PUT /courses/{id}/lessons/{lid} with { order_index } for each moved lesson.
   */
  const reorderLessons = async (reordered: any[]) => {
    if (!course) return;
    setCourse(prev => prev ? { ...prev, lessons: reordered } : prev);
    try {
      await Promise.all(
        reordered.map(l => coursesApi.updateLesson(course.id, l.id, { order_index: l.order_index }))
      );
    } catch { toast.error('Reorder failed — refresh to sync'); }
  };

  const lessonDrag = useDragReorder(course?.lessons ?? [], reorderLessons);

  /* ── Topics ── */
  const getNewTopicTitle = (lessonId: number) => newTopicTitles[lessonId] ?? '';
  const setNewTopicTitle = (lessonId: number, val: string) =>
    setNewTopicTitles(prev => ({ ...prev, [lessonId]: val }));

  const addTopic = async (lessonId: number) => {
    const title = getNewTopicTitle(lessonId);
    if (!title.trim() || !course) return;
    try {
      const lesson = course.lessons.find(l => l.id === lessonId);
      const r = await coursesApi.createTopic(course.id, {
        title,
        lesson_id:   lessonId,
        order_index: lesson?.topics?.length ?? 0,
      });
      setCourse(prev => prev ? {
        ...prev,
        lessons: prev.lessons.map(l =>
          l.id === lessonId ? { ...l, topics: [...(l.topics || []), r.data] } : l),
      } : prev);
      setNewTopicTitle(lessonId, '');
      toast.success('Topic added!');
    } catch { toast.error('Failed to add topic'); }
  };

  const deleteTopic = async (lessonId: number, topicId: number) => {
    if (!course || !window.confirm('Delete this topic?')) return;
    try {
      await coursesApi.deleteTopic(course.id, topicId);
      setCourse(prev => prev ? {
        ...prev,
        lessons: prev.lessons.map(l =>
          l.id === lessonId
            ? { ...l, topics: l.topics.filter((t: any) => t.id !== topicId) }
            : l),
      } : prev);
      setTopicContents(prev => { const n = { ...prev }; delete n[topicId]; return n; });
      toast.success('Topic deleted');
    } catch { toast.error('Failed to delete topic'); }
  };

  /**
   * Toggle is_free_preview on a topic.
   * Calls PATCH /courses/{id}/topics/{tid} with { is_free_preview }.
   */
  const toggleFreePreview = async (lessonId: number, topic: any) => {
    if (!course) return;
    setTogglingPreview(topic.id);
    try {
      await coursesApi.updateTopic(course.id, topic.id, {
        is_free_preview: !topic.is_free_preview,
      });
      setCourse(prev => prev ? {
        ...prev,
        lessons: prev.lessons.map(l =>
          l.id === lessonId
            ? {
                ...l,
                topics: l.topics.map((t: any) =>
                  t.id === topic.id ? { ...t, is_free_preview: !t.is_free_preview } : t),
              }
            : l),
      } : prev);
      toast.success(!topic.is_free_preview ? 'Set as free preview' : 'Preview removed');
    } catch { toast.error('Failed to update preview flag'); }
    finally { setTogglingPreview(null); }
  };

  /**
   * Persist topic order within a lesson after drag-and-drop.
   */
  const reorderTopics = async (lessonId: number, reordered: any[]) => {
    if (!course) return;
    setCourse(prev => prev ? {
      ...prev,
      lessons: prev.lessons.map(l =>
        l.id === lessonId ? { ...l, topics: reordered } : l),
    } : prev);
    try {
      await Promise.all(
        reordered.map(t => coursesApi.updateTopic(course.id, t.id, { order_index: t.order_index }))
      );
    } catch { toast.error('Reorder failed — refresh to sync'); }
  };

  /* ── Topic content loading ── */
  const loadTopicContents = async (topicId: number) => {
    if (!course || topicContents[topicId] !== undefined) return;
    try {
      const r = await coursesApi.getTopicContent(course.id, topicId);
      setTopicContents(prev => ({ ...prev, [topicId]: r.data.contents || [] }));
    } catch {
      setTopicContents(prev => ({ ...prev, [topicId]: [] }));
    }
  };

  /* ── File upload ── */
  const uploadTopicContent = async (topicId: number, file: File) => {
    if (!course) return;
    setUploadingContent(topicId);
    try {
      const r = await coursesApi.uploadContent(course.id, topicId, file);
      setTopicContents(prev => ({
        ...prev,
        [topicId]: [...(prev[topicId] || []), r.data],
      }));
      toast.success('Content uploaded!');
    } catch { toast.error('Upload failed'); }
    finally { setUploadingContent(null); }
  };

  /* ── Text/rich content ── */
  const initTopicForm = (topicId: number) => {
    if (topicForms[topicId]) return;
    setTopicForms(prev => ({
      ...prev,
      [topicId]: { showTextEditor: false, textTitle: '', textBody: '', savingText: false },
    }));
  };

  const updateTopicForm = (topicId: number, patch: Partial<TopicFormState[number]>) =>
    setTopicForms(prev => ({
      ...prev,
      [topicId]: { ...prev[topicId], ...patch },
    }));

  /**
   * Save a text-based content block (body field, content_type=text).
   * Uses the same upload-content endpoint with a JSON body option,
   * OR a dedicated text-content endpoint if your API exposes one.
   * Adjust the API call below to match your actual endpoint.
   */
  const saveTextContent = async (topicId: number) => {
    if (!course) return;
    const form = topicForms[topicId];
    if (!form?.textTitle.trim() || !form?.textBody.trim()) {
      toast.error('Title and content are required');
      return;
    }
    updateTopicForm(topicId, { savingText: true });
    try {
      // POST /courses/{course_id}/topics/{topic_id}/content/text
      const r = await coursesApi.addTextContent(course.id, topicId, {
        title: form.textTitle,
        body:  form.textBody,
      });
      setTopicContents(prev => ({
        ...prev,
        [topicId]: [...(prev[topicId] || []), r.data],
      }));
      updateTopicForm(topicId, { showTextEditor: false, textTitle: '', textBody: '' });
      toast.success('Content saved!');
    } catch (err: any) {
      console.log(err);
      toast.error(err.response?.data?.detail || 'Failed to save content');
    } finally {
      updateTopicForm(topicId, { savingText: false });
    }
  };

  /* ── Delete content ── */
  const deleteTopicContent = async (topicId: number, contentId: number) => {
    if (!course || !window.confirm('Delete this content?')) return;
    setDeletingContent(contentId);
    try {
      await coursesApi.deleteContent?.(course.id, topicId, contentId);
      setTopicContents(prev => ({
        ...prev,
        [topicId]: (prev[topicId] || []).filter(c => c.id !== contentId),
      }));
      toast.success('Content deleted');
    } catch { toast.error('Failed to delete content'); }
    finally { setDeletingContent(null); }
  };

  /* ── Submit for approval ── */
  const submitForApproval = async () => {
    if (!course) return;
    try {
      await coursesApi.submitForApproval(course.id);
      toast.success('Submitted for admin review!');
      navigate('/creator/courses');
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Submission failed');
    }
  };

  /* ── Category / tag helpers ── */
  const toggleCategory = (cid: number) =>
    setDetails(prev => ({
      ...prev,
      category_ids: prev.category_ids.includes(cid)
        ? prev.category_ids.filter(c => c !== cid)
        : [...prev.category_ids, cid],
    }));

  const toggleTag = (tid: number) =>
    setDetails(prev => ({
      ...prev,
      tag_ids: prev.tag_ids.includes(tid)
        ? prev.tag_ids.filter(t => t !== tid)
        : [...prev.tag_ids, tid],
    }));

  if (loading) return <Spinner />;

  /* ══════════════════════════════════════════
     Render
     ══════════════════════════════════════════ */
  return (
    <div className="fade-in">
      <PageTitle
        title={isEdit ? 'Edit Course' : 'Create New Course'}
        subtitle="Share your knowledge with the world"
        crumbs={[
          { label: 'Creator', href: '/creator' },
          { label: 'Courses', href: '/creator/courses' },
          { label: isEdit ? 'Edit' : 'New' },
        ]}
      />

      {/* ── Step indicator ── */}
      <div className="step-indicator mb-4">
        {STEPS.map((s, i) => (
          <button
            key={s}
            className={`step-dot ${i === step ? 'active' : i < step ? 'done' : ''}`}
            onClick={() => goToStep(i)}
            title={(!isEdit && !course && i > 0) ? 'Save details first' : s}
          >
            {i < step ? <><i className="bi bi-check me-1" />{s}</> : s}
          </button>
        ))}
      </div>

      <div className="card studio-step">

        {/* ════════════════════════════════════
            STEP 0 — Details
            ════════════════════════════════════ */}
        {step === 0 && (
          <div>
            <h5 className="fw-bold mb-4">Course Details</h5>
            <div className="row g-3">

              <div className="col-12">
                <label className="form-label fw-600 small">Course Title *</label>
                <input
                  className="form-control"
                  placeholder="e.g. Complete Python Bootcamp"
                  value={details.title}
                  onChange={e => setDetails(p => ({ ...p, title: e.target.value }))}
                />
              </div>

              <div className="col-12">
                <label className="form-label fw-600 small">Short Description</label>
                <input
                  className="form-control"
                  placeholder="One-line summary"
                  value={details.short_description}
                  onChange={e => setDetails(p => ({ ...p, short_description: e.target.value }))}
                  maxLength={500}
                />
              </div>

              <div className="col-12">
                <label className="form-label fw-600 small">Full Description</label>
                <textarea
                  className="form-control" rows={5}
                  placeholder="Describe what students will learn…"
                  value={details.description}
                  onChange={e => setDetails(p => ({ ...p, description: e.target.value }))}
                />
              </div>

              <div className="col-4">
                <label className="form-label fw-600 small">Level</label>
                <select className="form-select" value={details.level}
                  onChange={e => setDetails(p => ({ ...p, level: e.target.value }))}>
                  {LEVELS.map(l => (
                    <option key={l} value={l} style={{ textTransform: 'capitalize' }}>{l}</option>
                  ))}
                </select>
              </div>

              <div className="col-4">
                <label className="form-label fw-600 small">Language</label>
                <select className="form-select" value={details.lang}
                  onChange={e => setDetails(p => ({ ...p, lang: e.target.value }))}>
                  <option value="en">English</option>
                  <option value="fr">French</option>
                  <option value="yo">Yoruba</option>
                  <option value="ha">Hausa</option>
                  <option value="ig">Igbo</option>
                </select>
              </div>

              <div className="col-4">
                <label className="form-label fw-600 small">Duration (weeks)</label>
                <input
                  type="number" className="form-control" min={1}
                  value={details.duration_weeks}
                  onChange={e => setDetails(p => ({ ...p, duration_weeks: e.target.value }))}
                />
              </div>

              <div className="col-12">
                <label className="form-label fw-600 small">
                  Requirements <span className="text-muted">(one per line)</span>
                </label>
                <textarea
                  className="form-control" rows={3}
                  placeholder={"Basic computer knowledge\nInternet connection"}
                  value={details.requirements}
                  onChange={e => setDetails(p => ({ ...p, requirements: e.target.value }))}
                />
              </div>

              <div className="col-12">
                <label className="form-label fw-600 small">
                  What Students Will Learn <span className="text-muted">(one per line)</span>
                </label>
                <textarea
                  className="form-control" rows={3}
                  placeholder={"Build full-stack apps\nDeploy to production"}
                  value={details.what_you_learn}
                  onChange={e => setDetails(p => ({ ...p, what_you_learn: e.target.value }))}
                />
              </div>

              {/* ── Categories ── */}
              {categories.length > 0 && (
                <div className="col-12">
                  <label className="form-label fw-600 small">Categories</label>
                  <div className="d-flex flex-wrap gap-2">
                    {categories.map(cat => {
                      const selected = details.category_ids.includes(cat.id);
                      return (
                        <button
                          key={cat.id} type="button"
                          className={`btn btn-sm ${selected ? 'btn-primary' : 'btn-outline-secondary'}`}
                          style={{ fontSize: '0.75rem' }}
                          onClick={() => toggleCategory(cat.id)}
                        >
                          {selected && <i className="bi bi-check me-1" />}
                          {cat.title}
                        </button>
                      );
                    })}
                  </div>
                  {details.category_ids.length === 0 && (
                    <div className="text-muted small mt-1">Select at least one category</div>
                  )}
                </div>
              )}

              {/* ── Tags ── */}
              {tags.length > 0 && (
                <div className="col-12">
                  <label className="form-label fw-600 small">
                    Tags <span className="text-muted">(optional)</span>
                  </label>
                  <div className="d-flex flex-wrap gap-2">
                    {tags.map(tag => {
                      const selected = details.tag_ids.includes(tag.id);
                      return (
                        <button
                          key={tag.id} type="button"
                          className={`btn btn-sm ${selected ? 'btn-accent' : 'btn-outline-secondary'}`}
                          style={{ fontSize: '0.75rem' }}
                          onClick={() => toggleTag(tag.id)}
                        >
                          {selected && <i className="bi bi-check me-1" />}
                          {tag.name}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            <div className="d-flex justify-content-end mt-4">
              <button
                className="btn btn-primary fw-600"
                onClick={() => saveCourse(1)}
                disabled={saving || !details.title.trim()}
              >
                {saving
                  ? <><span className="spinner-border spinner-border-sm me-2" />Saving…</>
                  : isEdit ? 'Save & Continue →' : 'Create Course →'}
              </button>
            </div>
          </div>
        )}

        {/* ════════════════════════════════════
            STEP 1 — Curriculum
            Drag-to-reorder lessons and topics,
            per-topic free-preview toggle,
            file upload + text content authoring.
            ════════════════════════════════════ */}
        {step === 1 && course && (
          <div>
            <div className="d-flex align-items-center justify-content-between mb-4">
              <h5 className="fw-bold mb-0">Curriculum Builder</h5>
              <span className="text-muted small">
                <i className="bi bi-grip-vertical me-1" />Drag lessons or topics to reorder
              </span>
            </div>

            {(course.lessons || []).length === 0 && (
              <div className="text-center text-muted py-4" style={{ fontSize: '0.875rem' }}>
                <i className="bi bi-collection d-block mb-2" style={{ fontSize: '2rem' }} />
                No lessons yet. Add your first lesson below.
              </div>
            )}

            {/* ─── Lesson list (draggable) ─── */}
            {(course.lessons || []).map((lesson: any, li: number) => {
              const topicDrag = {
                handleDragStart: (idx: number) => { (topicDrag as any)._src = idx; },
                handleDragOver:  (e: React.DragEvent) => e.preventDefault(),
                handleDrop:      (idx: number) => {
                  const src = (topicDrag as any)._src;
                  if (src === null || src === undefined || src === idx) return;
                  const topics = [...(lesson.topics || [])];
                  const [moved] = topics.splice(src, 1);
                  topics.splice(idx, 0, moved);
                  reorderTopics(lesson.id, topics.map((t, i) => ({ ...t, order_index: i })));
                  (topicDrag as any)._src = null;
                },
                _src: null as number | null,
              };

              return (
                <div
                  key={lesson.id}
                  className="mb-3 border rounded-3 overflow-hidden"
                  draggable
                  onDragStart={() => lessonDrag.handleDragStart(li)}
                  onDragOver={lessonDrag.handleDragOver}
                  onDrop={() => lessonDrag.handleDrop(li)}
                  style={{ cursor: 'grab' }}
                >
                  {/* Lesson header */}
                  <div className="p-3 d-flex align-items-center gap-2" style={{ background: 'var(--bg)' }}>
                    <i className="bi bi-grip-vertical text-muted" style={{ cursor: 'grab', fontSize: '1rem' }} />
                    <i className="bi bi-collection text-primary" />
                    <span className="fw-700 flex-1" style={{ fontSize: '0.9rem' }}>
                      <span className="text-muted me-2" style={{ fontSize: '0.75rem' }}>
                        Lesson {li + 1}
                      </span>
                      {lesson.title}
                    </span>
                    <span className="badge bg-secondary-subtle text-secondary me-1" style={{ fontSize: '0.68rem' }}>
                      {(lesson.topics || []).length} topics
                    </span>
                    <button
                      className="btn btn-sm btn-outline-secondary"
                      onClick={() => {
                        const opening = activeLesson !== lesson.id;
                        setActiveLesson(opening ? lesson.id : null);
                        if (opening) {
                          (lesson.topics || []).forEach((t: any) => {
                            initTopicForm(t.id);
                            loadTopicContents(t.id);
                          });
                        }
                      }}
                    >
                      <i className={`bi ${activeLesson === lesson.id ? 'bi-chevron-up' : 'bi-chevron-down'}`} />
                    </button>
                    <button
                      className="btn btn-sm btn-outline-danger"
                      onClick={() => deleteLesson(lesson.id)}
                      title="Delete lesson"
                    >
                      <i className="bi bi-trash" />
                    </button>
                  </div>

                  {/* Topic list */}
                  {activeLesson === lesson.id && (
                    <div className="p-3" style={{ background: 'var(--surface)' }}>
                      {(lesson.topics || []).length === 0 && (
                        <div className="text-muted small mb-3 ps-2">
                          No topics yet. Add the first topic below.
                        </div>
                      )}

                      {(lesson.topics || []).map((topic: any, ti: number) => (
                        <div
                          key={topic.id}
                          className="mb-3 border rounded-2 overflow-hidden"
                          draggable
                          onDragStart={() => { (topicDrag as any)._src = ti; }}
                          onDragOver={topicDrag.handleDragOver}
                          onDrop={() => topicDrag.handleDrop(ti)}
                          style={{ background: 'var(--card-bg, #fff)', cursor: 'grab' }}
                        >
                          {/* Topic header row */}
                          <div className="d-flex align-items-center gap-2 p-2">
                            <i className="bi bi-grip-vertical text-muted" style={{ fontSize: '0.85rem' }} />
                            <i className="bi bi-file-earmark-play text-muted" style={{ fontSize: '0.85rem' }} />
                            <span className="flex-1 fw-600" style={{ fontSize: '0.85rem' }}>
                              <span className="text-muted me-1" style={{ fontSize: '0.72rem' }}>
                                {li + 1}.{ti + 1}
                              </span>
                              {topic.title}
                            </span>

                            {/* ── Free Preview Toggle ── */}
                            <button
                              className={`btn btn-sm ${topic.is_free_preview ? 'btn-success' : 'btn-outline-secondary'}`}
                              style={{ fontSize: '0.7rem', padding: '2px 8px' }}
                              title={topic.is_free_preview ? 'Free preview — click to remove' : 'Set as free preview'}
                              disabled={togglingPreview === topic.id}
                              onClick={() => toggleFreePreview(lesson.id, topic)}
                            >
                              {togglingPreview === topic.id
                                ? <span className="spinner-border spinner-border-sm" style={{ width: '0.65rem', height: '0.65rem' }} />
                                : <>
                                    <i className={`bi ${topic.is_free_preview ? 'bi-eye-fill' : 'bi-eye'} me-1`} />
                                    {topic.is_free_preview ? 'Free Preview' : 'Preview'}
                                  </>}
                            </button>

                            {/* ── Upload file ── */}
                            <label className="btn btn-sm btn-outline-primary mb-0" style={{ cursor: 'pointer', fontSize: '0.72rem' }}>
                              {uploadingContent === topic.id
                                ? <span className="spinner-border spinner-border-sm" />
                                : <><i className="bi bi-cloud-upload me-1" />Upload</>}
                              <input
                                type="file" hidden
                                onChange={e => {
                                  const f = e.target.files?.[0];
                                  if (f) uploadTopicContent(topic.id, f);
                                  e.target.value = '';
                                }}
                              />
                            </label>

                            {/* ── Add text content ── */}
                            <button
                              className="btn btn-sm btn-outline-secondary"
                              style={{ fontSize: '0.72rem' }}
                              title="Add text/article content"
                              onClick={() => {
                                initTopicForm(topic.id);
                                updateTopicForm(topic.id, {
                                  showTextEditor: !topicForms[topic.id]?.showTextEditor,
                                });
                              }}
                            >
                              <i className="bi bi-pencil-square me-1" />Text
                            </button>

                            {/* ── Delete topic ── */}
                            <button
                              className="btn btn-sm btn-outline-danger"
                              style={{ fontSize: '0.72rem' }}
                              onClick={() => deleteTopic(lesson.id, topic.id)}
                              title="Delete topic"
                            >
                              <i className="bi bi-trash" />
                            </button>
                          </div>

                          {/* ── Inline text editor ── */}
                          {topicForms[topic.id]?.showTextEditor && (
                            <div className="p-3 border-top" style={{ background: 'var(--bg)' }}>
                              <div className="mb-2">
                                <label className="form-label fw-600 small mb-1">Content Title</label>
                                <input
                                  className="form-control form-control-sm"
                                  placeholder="e.g. Introduction, Chapter Summary…"
                                  value={topicForms[topic.id]?.textTitle ?? ''}
                                  onChange={e => updateTopicForm(topic.id, { textTitle: e.target.value })}
                                />
                              </div>
                              <div className="mb-2">
                                <label className="form-label fw-600 small mb-1">Content Body</label>
                                <textarea
                                  className="form-control form-control-sm"
                                  rows={6}
                                  placeholder="Write your lesson content, article, or notes here…"
                                  value={topicForms[topic.id]?.textBody ?? ''}
                                  onChange={e => updateTopicForm(topic.id, { textBody: e.target.value })}
                                  style={{ fontFamily: 'monospace', fontSize: '0.82rem', resize: 'vertical' }}
                                />
                              </div>
                              <div className="d-flex gap-2 justify-content-end">
                                <button
                                  className="btn btn-sm btn-outline-secondary"
                                  onClick={() => updateTopicForm(topic.id, { showTextEditor: false, textTitle: '', textBody: '' })}
                                >
                                  Cancel
                                </button>
                                <button
                                  className="btn btn-sm btn-primary fw-600"
                                  disabled={topicForms[topic.id]?.savingText}
                                  onClick={() => saveTextContent(topic.id)}
                                >
                                  {topicForms[topic.id]?.savingText
                                    ? <><span className="spinner-border spinner-border-sm me-1" />Saving…</>
                                    : <><i className="bi bi-check me-1" />Save Content</>}
                                </button>
                              </div>
                            </div>
                          )}

                          {/* ── Content list ── */}
                          {(topicContents[topic.id] || []).length > 0 && (
                            <div className="border-top" style={{ fontSize: '0.78rem' }}>
                              {topicContents[topic.id].map((c: TopicContent) => (
                                <div key={c.id} className="d-flex align-items-center gap-2 px-3 py-2 border-bottom">
                                  <i className={`bi ${CONTENT_ICONS[c.content_type] ?? 'bi-file-earmark'} text-muted`} />
                                  <span className="flex-1 text-muted text-truncate" style={{ maxWidth: 280 }}>
                                    {c.title || c.file_path}
                                  </span>
                                  <span className="badge bg-light text-muted" style={{ fontSize: '0.65rem' }}>
                                    {c.content_type}
                                  </span>
                                  {/*
                                    SECURITY: Never expose the raw file URL to the DOM.
                                    The creator admin view gets a token-gated preview link instead.
                                    Students get a signed URL from the serve-content endpoint.
                                  */}
                                  <span className="text-muted" style={{ fontSize: '0.72rem' }}>
                                    <i className="bi bi-shield-lock me-1" />Protected
                                  </span>
                                  <button
                                    className="btn btn-sm btn-link text-danger p-0"
                                    disabled={deletingContent === c.id}
                                    onClick={() => deleteTopicContent(topic.id, c.id)}
                                  >
                                    {deletingContent === c.id
                                      ? <span className="spinner-border spinner-border-sm" />
                                      : <i className="bi bi-x-circle" />}
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Loading indicator while fetching content */}
                          {topicContents[topic.id] === undefined && (
                            <div className="px-3 py-2 text-muted border-top" style={{ fontSize: '0.75rem' }}>
                              <span className="spinner-border spinner-border-sm me-2" style={{ width: '0.7rem', height: '0.7rem' }} />
                              Loading content…
                            </div>
                          )}
                        </div>
                      ))}

                      {/* Add topic row */}
                      <div className="d-flex gap-2 mt-3">
                        <input
                          className="form-control form-control-sm"
                          placeholder="New topic title…"
                          value={getNewTopicTitle(lesson.id)}
                          onChange={e => setNewTopicTitle(lesson.id, e.target.value)}
                          onKeyDown={e => e.key === 'Enter' && addTopic(lesson.id)}
                        />
                        <button
                          className="btn btn-sm btn-success"
                          onClick={() => addTopic(lesson.id)}
                        >
                          <i className="bi bi-plus me-1" />Add Topic
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Add lesson row */}
            <div className="d-flex gap-2 mt-3 mb-4">
              <input
                className="form-control"
                placeholder="New lesson / section title…"
                value={newLessonTitle}
                onChange={e => setNewLessonTitle(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addLesson()}
              />
              <button className="btn btn-primary" onClick={addLesson}>
                <i className="bi bi-plus-circle me-1" />Add Lesson
              </button>
            </div>

            <div className="d-flex justify-content-between mt-2">
              <button className="btn btn-outline-secondary" onClick={() => setStep(0)}>← Back</button>
              <button className="btn btn-primary" onClick={() => setStep(2)}>Continue →</button>
            </div>
          </div>
        )}

        {/* ════════════════════════════════════
            STEP 2 — Media
            ════════════════════════════════════ */}
        {step === 2 && course && (
          <div>
            <h5 className="fw-bold mb-4">Course Media</h5>

            <label className="form-label fw-600 small">Course Thumbnail</label>
            <div
              className="dropzone mb-4"
              onClick={() => thumbRef.current?.click()}
              style={{ cursor: 'pointer' }}
            >
              {thumbnailPreview
                ? <img src={thumbnailPreview} alt="Thumbnail preview"
                    style={{ maxHeight: 200, maxWidth: '100%', borderRadius: 8 }} />
                : (
                  <>
                    <i className="bi bi-image text-primary d-block mb-2" style={{ fontSize: '2rem' }} />
                    <div className="text-muted small">Click to upload thumbnail (JPG, PNG, WebP)</div>
                  </>
                )}
              <input
                ref={thumbRef} type="file" accept="image/*" hidden
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) {
                    setThumbnailPreview(URL.createObjectURL(f));
                    uploadThumbnail(f);
                  }
                  e.target.value = '';
                }}
              />
            </div>

            <div className="alert alert-info d-flex gap-2" style={{ fontSize: '0.8rem' }}>
              <i className="bi bi-info-circle flex-shrink-0 mt-1" />
              Upload topic content (videos, PDFs, etc.) per topic in the Curriculum tab.
            </div>

            <div className="d-flex justify-content-between mt-4">
              <button className="btn btn-outline-secondary" onClick={() => setStep(1)}>← Back</button>
              <button className="btn btn-primary" onClick={() => setStep(3)}>Continue →</button>
            </div>
          </div>
        )}

        {/* ════════════════════════════════════
            STEP 3 — Pricing
            ════════════════════════════════════ */}
        {step === 3 && (
          <div>
            <h5 className="fw-bold mb-4">Pricing & Access</h5>

            <div className="row g-3">
              <div className="col-sm-6">
                <label className="form-label fw-600 small">Payment Model</label>
                <select
                  className="form-select"
                  value={pricing.payment_type}
                  onChange={e => setPricing(p => ({ ...p, payment_type: e.target.value }))}
                >
                  {PAYMENT_TYPES.map(pt => (
                    <option key={pt.value} value={pt.value}>{pt.label}</option>
                  ))}
                </select>
              </div>

              {pricing.payment_type !== 'free' && (
                <div className="col-sm-6">
                  <label className="form-label fw-600 small">Price (₦)</label>
                  <input
                    type="number" className="form-control" min={0}
                    value={pricing.fee}
                    onChange={e => setPricing(p => ({ ...p, fee: Number(e.target.value) }))}
                  />
                </div>
              )}

              {pricing.payment_type === 'subscription' && (
                <div className="col-sm-6">
                  <label className="form-label fw-600 small">Billing Interval</label>
                  <select
                    className="form-select"
                    value={pricing.subscription_interval}
                    onChange={e => setPricing(p => ({ ...p, subscription_interval: e.target.value }))}
                  >
                    <option value="">Select interval…</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                  </select>
                </div>
              )}
            </div>

            <div className="d-flex justify-content-between mt-4">
              <button className="btn btn-outline-secondary" onClick={() => setStep(2)}>← Back</button>
              <div className="d-flex gap-2">
                <button
                  className="btn btn-outline-primary fw-600"
                  onClick={() => saveCourse()}
                  disabled={saving}
                >
                  {saving
                    ? <><span className="spinner-border spinner-border-sm me-2" />Saving…</>
                    : 'Save Pricing'}
                </button>
                <button
                  className="btn btn-primary fw-600"
                  onClick={() => saveCourse(4)}
                  disabled={saving}
                >
                  {saving
                    ? <><span className="spinner-border spinner-border-sm me-2" />Saving…</>
                    : 'Save & Continue →'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ════════════════════════════════════
            STEP 4 — Publish
            ════════════════════════════════════ */}
        {step === 4 && course && (
          <div className="text-center py-3">
            <div className="stat-icon green mx-auto mb-4" style={{ width: 80, height: 80, fontSize: '2rem' }}>
              <i className="bi bi-check-circle" />
            </div>
            <h5 className="fw-bold mb-2">Ready to Publish!</h5>
            <p className="text-muted mb-4" style={{ maxWidth: 400, margin: '0 auto 1.5rem' }}>
              Submit your course for admin review. Once approved it will be visible to students.
            </p>

            <div className="card p-3 text-start mb-4" style={{ maxWidth: 360, margin: '0 auto 1.5rem' }}>
              <div className="fw-700 mb-2">{course.title}</div>
              <div className="d-flex gap-3 text-muted" style={{ fontSize: '0.8rem' }}>
                <span><i className="bi bi-collection me-1" />{course.lessons?.length ?? 0} lessons</span>
                <span>{course.fee > 0 ? `₦${course.fee.toLocaleString()}` : 'Free'}</span>
                <span className={`badge ${
                  course.status === 'published' ? 'bg-success' :
                  course.status === 'pending'   ? 'bg-warning text-dark' :
                  'bg-secondary'
                }`}>{course.status}</span>
              </div>
            </div>

            <div className="d-flex gap-3 justify-content-center flex-wrap">
              <button className="btn btn-outline-secondary" onClick={() => setStep(3)}>← Back</button>
              {course.status !== 'pending' && course.status !== 'published' && (
                <button className="btn btn-success fw-600" onClick={submitForApproval}>
                  <i className="bi bi-send me-2" />Submit for Review
                </button>
              )}
              {course.status === 'pending' && (
                <div className="alert alert-info mb-0 py-2 px-3" style={{ fontSize: '0.85rem' }}>
                  <i className="bi bi-hourglass-split me-2" />
                  Under review — you can still update details above and save.
                </div>
              )}
              {course.status === 'published' && (
                <div className="alert alert-success mb-0 py-2 px-3" style={{ fontSize: '0.85rem' }}>
                  <i className="bi bi-check-circle me-2" />
                  Published! Updates save automatically on each tab.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}