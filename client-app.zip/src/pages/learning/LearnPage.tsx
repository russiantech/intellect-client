// import { useState, useEffect, useRef } from 'react';
// import { useParams, Link, useNavigate } from 'react-router-dom';
// import toast from 'react-hot-toast';
// import { coursesApi, enrollmentsApi, aiApi } from '@/services/api';
// import { Course, Topic, TopicContent } from '@/types';
// import { Spinner } from '@/components/shared';

// interface AiMsg { role: 'user' | 'assistant'; content: string; }

// export default function LearnPage() {
//   const { slug } = useParams<{ slug: string }>();
//   const navigate = useNavigate();
//   const [course, setCourse] = useState<Course | null>(null);
//   const [activeTopic, setActiveTopic] = useState<Topic | null>(null);
//   const [topicContent, setTopicContent] = useState<any>(null);
//   const [loading, setLoading] = useState(true);
//   const [contentLoading, setContentLoading] = useState(false);
//   const [openLessons, setOpenLessons] = useState<Set<number>>(new Set([0]));
//   const [completedTopics, setCompletedTopics] = useState<Set<number>>(new Set());
//   const [aiOpen, setAiOpen] = useState(false);
//   const [aiMessages, setAiMessages] = useState<AiMsg[]>([]);
//   const [aiInput, setAiInput] = useState('');
//   const [aiLoading, setAiLoading] = useState(false);
//   const aiEndRef = useRef<HTMLDivElement>(null);

//   useEffect(() => {
//     if (!slug) return;
//     coursesApi.get(slug).then(r => {
//       const c: Course = r.data;
//       if (!c.is_enrolled) { navigate(`/courses/${slug}`); return; }
//       setCourse(c);
//       // Auto-open first lesson, select first topic
//       if (c.lessons.length > 0 && c.lessons[0].topics.length > 0) {
//         const firstTopic = c.lessons[0].topics[0];
//         setActiveTopic(firstTopic);
//         loadTopicContent(c.id, firstTopic.id);
//       }
//     }).catch(() => navigate('/explore')).finally(() => setLoading(false));
//   }, [slug]);

//   const loadTopicContent = async (courseId: number, topicId: number) => {
//     setContentLoading(true);
//     try {
//       const res = await coursesApi.getTopicContent(courseId, topicId);
//       setTopicContent(res.data);
//     } catch (err: any) {
//       toast.error(err.response?.data?.detail || 'Failed to load content');
//     } finally { setContentLoading(false); }
//   };

//   const handleTopicClick = async (topic: Topic) => {
//     if (!course) return;
//     setActiveTopic(topic);
//     await loadTopicContent(course.id, topic.id);
//   };

//   const markComplete = async (topicId: number) => {
//     if (!course) return;
//     try {
//       const res = await enrollmentsApi.markProgress(topicId, true);
//       setCompletedTopics(prev => new Set([...prev, topicId]));
//       toast.success(`Progress: ${res.data.progress_pct}%`);
//       if (res.data.progress_pct >= 100) {
//         toast.success('🎉 Course completed! Certificate issued!', { duration: 5000 });
//       }
//       // Move to next topic
//       if (course) {
//         for (const lesson of course.lessons) {
//           const idx = lesson.topics.findIndex(t => t.id === topicId);
//           if (idx !== -1 && idx < lesson.topics.length - 1) {
//             handleTopicClick(lesson.topics[idx + 1]);
//             return;
//           }
//         }
//       }
//     } catch { toast.error('Could not save progress'); }
//   };

//   const sendAiMessage = async () => {
//     if (!aiInput.trim() || aiLoading) return;
//     const userMsg: AiMsg = { role: 'user', content: aiInput };
//     setAiMessages(prev => [...prev, userMsg]);
//     setAiInput('');
//     setAiLoading(true);
//     try {
//       const res = await aiApi.chat({
//         message: aiInput,
//         history: aiMessages,
//         course_id: course?.id,
//       });
//       setAiMessages(prev => [...prev, { role: 'assistant', content: res.data.reply }]);
//     } catch { setAiMessages(prev => [...prev, { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' }]); }
//     finally { setAiLoading(false); setTimeout(() => aiEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100); }
//   };

//   if (loading) return <Spinner />;
//   if (!course) return null;

//   const renderContent = (content: TopicContent) => {
//     const url = content.url || (content.file_path ? `/uploads/courses/content/${content.file_path}` : null);
//     if (!url && !content.body) return null;

//     switch (content.content_type) {
//       case 'video':
//         return (
//           <div className="video-wrapper mb-4" key={content.id}>
//             <video controls controlsList="nodownload" style={{ width: '100%', maxHeight: 480 }}>
//               <source src={url!} type={content.url?.includes('youtube') ? undefined : 'video/mp4'} />
//             </video>
//           </div>
//         );
//       case 'pdf':
//         return (
//           <div key={content.id} className="mb-4">
//             <iframe src={url!} className="pdf-viewer" title={content.title || 'PDF'} />
//             <a href={url!} target="_blank" rel="noreferrer" className="btn btn-sm btn-outline-primary mt-2">
//               <i className="bi bi-download me-1" /> Download PDF
//             </a>
//           </div>
//         );
//       case 'image':
//         return (
//           <div key={content.id} className="mb-4 text-center">
//             <img src={url!} alt={content.title || ''} className="img-fluid rounded" style={{ maxHeight: 480 }} />
//           </div>
//         );
//       case 'ppt':
//         return (
//           <div key={content.id} className="mb-4">
//             <div className="d-flex align-items-center gap-3 p-4 rounded-3" style={{ background: 'var(--bg)', border: '1px solid var(--border)' }}>
//               <i className="bi bi-file-earmark-slides text-danger" style={{ fontSize: '2rem' }} />
//               <div>
//                 <div className="fw-600">{content.title || 'Presentation'}</div>
//                 <div className="text-muted" style={{ fontSize: '0.8rem' }}>PowerPoint / Slides</div>
//               </div>
//               <a href={url!} target="_blank" rel="noreferrer" className="btn btn-sm btn-primary ms-auto">
//                 <i className="bi bi-download me-1" /> Download
//               </a>
//             </div>
//           </div>
//         );
//       case 'text':
//         return <div key={content.id} className="mb-4 prose" style={{ lineHeight: 1.8 }} dangerouslySetInnerHTML={{ __html: content.body || '' }} />;
//       case 'audio':
//         return (
//           <div key={content.id} className="mb-4">
//             <audio controls className="w-100"><source src={url!} /></audio>
//           </div>
//         );
//       default:
//         return url ? (
//           <div key={content.id} className="mb-4">
//             <a href={url} target="_blank" rel="noreferrer" className="btn btn-outline-primary btn-icon-start">
//               <i className="bi bi-file-earmark" /> Open {content.title || 'File'}
//             </a>
//           </div>
//         ) : null;
//     }
//   };

//   return (
//     <div className="learning-layout" style={{ height: `calc(100vh - var(--nav-height))` }}>
//       {/* Topic Sidebar */}
//       <aside className="topic-sidebar">
//         <div className="p-3 border-bottom">
//           <Link to={`/courses/${course.slug}`} className="text-muted d-flex align-items-center gap-2" style={{ fontSize: '0.8rem' }}>
//             <i className="bi bi-arrow-left" /> Back to course
//           </Link>
//           <h6 className="fw-700 mt-2 mb-0 truncate-2" style={{ fontSize: '0.875rem' }}>{course.title}</h6>
//           <div className="mt-1">
//             <div className="progress" style={{ height: 4 }}>
//               <div className="progress-bar" style={{ width: `${course.progress_pct}%` }} />
//             </div>
//             <span className="text-primary" style={{ fontSize: '0.72rem' }}>{course.progress_pct}% complete</span>
//           </div>
//         </div>

//         <div className="lesson-accordion">
//           {course.lessons.map((lesson, li) => (
//             <div key={lesson.id}>
//               <button
//                 className="lesson-header w-100 border-0"
//                 onClick={() => setOpenLessons(prev => { const s = new Set(prev); s.has(li) ? s.delete(li) : s.add(li); return s; })}
//               >
//                 <span style={{ fontWeight: 600, fontSize: '0.8rem' }}>{lesson.title}</span>
//                 <div className="d-flex align-items-center gap-2">
//                   <span className="text-muted" style={{ fontSize: '0.7rem' }}>{lesson.topics.length}</span>
//                   <i className={`bi ${openLessons.has(li) ? 'bi-chevron-up' : 'bi-chevron-down'} text-muted`} style={{ fontSize: '0.7rem' }} />
//                 </div>
//               </button>
//               {openLessons.has(li) && lesson.topics.map(topic => (
//                 <div
//                   key={topic.id}
//                   className={`topic-item ${activeTopic?.id === topic.id ? 'active' : ''} ${completedTopics.has(topic.id) || topic.id < (activeTopic?.id || 0) ? 'completed' : ''}`}
//                   onClick={() => handleTopicClick(topic)}
//                 >
//                   <i className={`bi ${completedTopics.has(topic.id) ? 'bi-check-circle-fill text-success' : activeTopic?.id === topic.id ? 'bi-play-circle-fill text-primary' : 'bi-circle text-muted'} topic-check`} />
//                   <span className="flex-1" style={{ fontSize: '0.78rem' }}>{topic.title}</span>
//                   {topic.duration_minutes && <span className="text-muted" style={{ fontSize: '0.65rem' }}>{topic.duration_minutes}m</span>}
//                 </div>
//               ))}
//             </div>
//           ))}
//         </div>
//       </aside>

//       {/* Main content */}
//       <main className="content-player p-0">
//         <div className="p-4" style={{ maxWidth: 900, margin: '0 auto' }}>
//           {activeTopic ? (
//             <>
//               <div className="d-flex align-items-start justify-content-between mb-3">
//                 <div>
//                   <h4 className="fw-bold mb-1">{activeTopic.title}</h4>
//                   {activeTopic.duration_minutes && (
//                     <span className="text-muted" style={{ fontSize: '0.8rem' }}><i className="bi bi-clock me-1" />{activeTopic.duration_minutes} min</span>
//                   )}
//                 </div>
//                 <button className="btn btn-sm btn-outline-primary" onClick={() => setAiOpen(p => !p)}>
//                   <i className="bi bi-robot me-1" /> Ask AI
//                 </button>
//               </div>

//               {contentLoading ? <Spinner /> : topicContent ? (
//                 <>
//                   {/* Render all content items */}
//                   {topicContent.contents?.map((c: TopicContent) => renderContent(c))}

//                   {/* Description */}
//                   {activeTopic.description && (
//                     <div className="card p-4 mb-4">
//                       <h6 className="fw-700 mb-2">About this topic</h6>
//                       <p style={{ fontSize: '0.875rem', lineHeight: 1.7 }}>{activeTopic.description}</p>
//                     </div>
//                   )}

//                   {/* Mark complete */}
//                   {!completedTopics.has(activeTopic.id) && (
//                     <div className="d-flex justify-content-end">
//                       <button className="btn btn-success btn-icon-start" onClick={() => markComplete(activeTopic.id)}>
//                         <i className="bi bi-check-circle" /> Mark as Complete
//                       </button>
//                     </div>
//                   )}
//                   {completedTopics.has(activeTopic.id) && (
//                     <div className="d-flex align-items-center gap-2 text-success">
//                       <i className="bi bi-check-circle-fill" /> Topic completed!
//                     </div>
//                   )}
//                 </>
//               ) : (
//                 <div className="text-center text-muted py-5">
//                   <i className="bi bi-exclamation-circle d-block mb-2" style={{ fontSize: '2rem' }} />
//                   No content available for this topic yet.
//                 </div>
//               )}
//             </>
//           ) : (
//             <div className="text-center text-muted py-5">
//               <i className="bi bi-play-circle d-block mb-3" style={{ fontSize: '3rem' }} />
//               <h5>Select a topic to start learning</h5>
//             </div>
//           )}
//         </div>
//       </main>

//       {/* AI Sidebar */}
//       <div className={`ai-sidebar ${aiOpen ? 'open' : ''}`}>
//         <div className="d-flex align-items-center justify-content-between p-3 border-bottom">
//           <div className="d-flex align-items-center gap-2">
//             <i className="bi bi-robot text-primary" />
//             <span className="fw-700" style={{ fontSize: '0.875rem' }}>Intellect AI</span>
//           </div>
//           <button className="btn btn-sm btn-outline-secondary" onClick={() => setAiOpen(false)}><i className="bi bi-x-lg" /></button>
//         </div>

//         <div className="ai-messages">
//           {aiMessages.length === 0 && (
//             <div className="text-center text-muted py-4" style={{ fontSize: '0.8rem' }}>
//               <i className="bi bi-chat-square-dots d-block mb-2" style={{ fontSize: '1.5rem' }} />
//               Ask me anything about this course or topic!
//             </div>
//           )}
//           {aiMessages.map((m, i) => (
//             <div key={i} className={`ai-msg ${m.role}`}>{m.content}</div>
//           ))}
//           {aiLoading && (
//             <div className="ai-msg assistant">
//               <span className="spinner-grow spinner-grow-sm text-primary" /> Thinking…
//             </div>
//           )}
//           <div ref={aiEndRef} />
//         </div>

//         <div className="p-3 border-top">
//           <div className="d-flex gap-2">
//             <input
//               type="text" className="form-control form-control-sm" placeholder="Ask a question…"
//               value={aiInput} onChange={e => setAiInput(e.target.value)}
//               onKeyDown={e => e.key === 'Enter' && sendAiMessage()}
//             />
//             <button className="btn btn-sm btn-primary" onClick={sendAiMessage} disabled={aiLoading}>
//               <i className="bi bi-send" />
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }



// // v2
// import {
//   useState,
//   useEffect,
//   useRef,
//   useCallback,
//   type KeyboardEvent,
// } from 'react';
// import { useParams, Link, useNavigate } from 'react-router-dom';
// import toast from 'react-hot-toast';
// import { coursesApi, enrollmentsApi, aiApi } from '@/services/api';
// import { Course, Topic, TopicContent } from '@/types';
// import { Spinner } from '@/components/shared';
// import '@/styles/pages/learning/LearnPage.css';

// /* ═══════════════════════════════════════════
//    Types
//    ═══════════════════════════════════════════ */
// interface AiMsg {
//   role: 'user' | 'assistant';
//   content: string;
// }

// /* ═══════════════════════════════════════════
//    Video resume helpers
//    ═══════════════════════════════════════════ */
// const VID_KEY = (topicId: number) => `vid_pos_${topicId}`;

// function saveVideoPosition(topicId: number, time: number) {
//   try {
//     if (time > 2) localStorage.setItem(VID_KEY(topicId), String(Math.floor(time)));
//   } catch { /* storage may be unavailable */ }
// }

// function loadVideoPosition(topicId: number): number {
//   try {
//     return Number(localStorage.getItem(VID_KEY(topicId))) || 0;
//   } catch { return 0; }
// }

// /* ═══════════════════════════════════════════
//    VideoPlayer — handles resume + save
//    ═══════════════════════════════════════════ */
// interface VideoPlayerProps {
//   src: string;
//   topicId: number;
// }

// function VideoPlayer({ src, topicId }: VideoPlayerProps) {
//   const videoRef  = useRef<HTMLVideoElement>(null);
//   const saveTimer = useRef<ReturnType<typeof setInterval> | null>(null);
//   const resumed   = useRef(false);

//   /* Restore saved position once metadata is ready */
//   const handleMetadata = useCallback(() => {
//     if (resumed.current) return;
//     const saved = loadVideoPosition(topicId);
//     if (saved > 0 && videoRef.current) {
//       videoRef.current.currentTime = saved;
//       resumed.current = true;
//     }
//   }, [topicId]);

//   /* Persist position every 5 s while playing */
//   const handlePlay = useCallback(() => {
//     if (saveTimer.current) clearInterval(saveTimer.current);
//     saveTimer.current = setInterval(() => {
//       if (videoRef.current) saveVideoPosition(topicId, videoRef.current.currentTime);
//     }, 5000);
//   }, [topicId]);

//   const handlePause = useCallback(() => {
//     if (saveTimer.current) { clearInterval(saveTimer.current); saveTimer.current = null; }
//     if (videoRef.current) saveVideoPosition(topicId, videoRef.current.currentTime);
//   }, [topicId]);

//   const handleEnded = useCallback(() => {
//     handlePause();
//     /* Clear saved position when the video is fully watched */
//     try { localStorage.removeItem(VID_KEY(topicId)); } catch { /* noop */ }
//   }, [topicId, handlePause]);

//   /* Reset resumed flag when topic changes */
//   useEffect(() => {
//     resumed.current = false;
//     return () => {
//       if (saveTimer.current) clearInterval(saveTimer.current);
//     };
//   }, [topicId, src]);

//   return (
//     <div className="learn-video-wrap">
//       <video
//         ref={videoRef}
//         controls
//         /* NOTE: nodownload only hides the native download button.
//            Seeking is always allowed — controlled by server range headers. */
//         controlsList="nodownload"
//         playsInline
//         onLoadedMetadata={handleMetadata}
//         onPlay={handlePlay}
//         onPause={handlePause}
//         onEnded={handleEnded}
//         key={src} /* re-mounts player when src changes */
//       >
//         <source src={src} type="video/mp4" />
//         Your browser does not support the video tag.
//       </video>
//     </div>
//   );
// }

// /* ═══════════════════════════════════════════
//    Content renderer
//    ═══════════════════════════════════════════ */
// function renderContent(content: TopicContent) {
//   const url = content.url ||
//     (content.file_path ? `/uploads/courses/content/${content.file_path}` : null);

//   if (!url && !content.body) return null;

//   switch (content.content_type) {
//     case 'video':
//       return url
//         ? <VideoPlayer key={content.id} src={url} topicId={content.id} />
//         : null;

//     case 'pdf':
//       return (
//         <div key={content.id} className="learn-pdf-wrap">
//           <iframe
//             src={url!}
//             className="learn-pdf-viewer"
//             title={content.title || 'PDF'}
//           />
//           <div style={{ padding: '0.6rem 0.75rem', borderTop: '1px solid var(--border)' }}>
//             <a
//               href={url!}
//               target="_blank"
//               rel="noreferrer"
//               className="btn btn-sm btn-outline-primary"
//             >
//               <i className="bi bi-download me-1" /> Download PDF
//             </a>
//           </div>
//         </div>
//       );

//     case 'image':
//       return (
//         <div key={content.id} className="learn-image-wrap">
//           <img src={url!} alt={content.title || ''} />
//         </div>
//       );

//     case 'ppt':
//       return (
//         <div key={content.id} className="learn-file-card">
//           <i className="bi bi-file-earmark-slides text-danger learn-file-icon" />
//           <div className="learn-file-info">
//             <div className="learn-file-name">{content.title || 'Presentation'}</div>
//             <div className="learn-file-type">PowerPoint / Slides</div>
//           </div>
//           <a
//             href={url!}
//             target="_blank"
//             rel="noreferrer"
//             className="btn btn-sm btn-primary ms-auto"
//           >
//             <i className="bi bi-download me-1" /> Download
//           </a>
//         </div>
//       );

//     case 'audio':
//       return (
//         <div key={content.id} style={{ marginBottom: '1.25rem' }}>
//           <audio controls className="w-100">
//             <source src={url!} />
//           </audio>
//         </div>
//       );

//     case 'text':
//       return (
//         <div
//           key={content.id}
//           className="learn-prose"
//           dangerouslySetInnerHTML={{ __html: content.body || '' }}
//         />
//       );

//     default:
//       return url ? (
//         <div key={content.id} style={{ marginBottom: '1.25rem' }}>
//           <a
//             href={url}
//             target="_blank"
//             rel="noreferrer"
//             className="btn btn-outline-primary"
//           >
//             <i className="bi bi-file-earmark me-1" />
//             Open {content.title || 'File'}
//           </a>
//         </div>
//       ) : null;
//   }
// }

// /* ═══════════════════════════════════════════
//    LearnPage
//    ═══════════════════════════════════════════ */
// export default function LearnPage() {
//   const { slug }  = useParams<{ slug: string }>();
//   const navigate  = useNavigate();

//   /* ── Core state ── */
//   const [course,          setCourse]          = useState<Course | null>(null);
//   const [activeTopic,     setActiveTopic]     = useState<Topic | null>(null);
//   const [topicContent,    setTopicContent]    = useState<any>(null);
//   const [loading,         setLoading]         = useState(true);
//   const [contentLoading,  setContentLoading]  = useState(false);
//   const [openLessons,     setOpenLessons]     = useState<Set<number>>(new Set([0]));
//   const [completedTopics, setCompletedTopics] = useState<Set<number>>(new Set());

//   /* ── Panel open/close ── */
//   const [sidebarOpen, setSidebarOpen] = useState(false);
//   const [aiOpen,      setAiOpen]      = useState(false);

//   /* ── AI chat ── */
//   const [aiMessages, setAiMessages] = useState<AiMsg[]>([]);
//   const [aiInput,    setAiInput]    = useState('');
//   const [aiLoading,  setAiLoading]  = useState(false);
//   const aiEndRef = useRef<HTMLDivElement>(null);

//   /* ── Lock body scroll when a drawer is open on mobile ── */
//   useEffect(() => {
//     document.body.style.overflow = (sidebarOpen || aiOpen) ? 'hidden' : '';
//     return () => { document.body.style.overflow = ''; };
//   }, [sidebarOpen, aiOpen]);

//   /* ── Load course ── */
//   useEffect(() => {
//     if (!slug) return;
//     coursesApi.get(slug)
//       .then(r => {
//         const c: Course = r.data;
//         if (!c.is_enrolled) { navigate(`/courses/${slug}`); return; }
//         setCourse(c);
//         if (c.lessons.length > 0 && c.lessons[0].topics.length > 0) {
//           const first = c.lessons[0].topics[0];
//           setActiveTopic(first);
//           fetchTopicContent(c.id, first.id);
//         }
//       })
//       .catch(() => navigate('/explore'))
//       .finally(() => setLoading(false));
//   }, [slug]);

//   /* ── Content loading ── */
//   const fetchTopicContent = async (courseId: number, topicId: number) => {
//     setContentLoading(true);
//     try {
//       const res = await coursesApi.getTopicContent(courseId, topicId);
//       setTopicContent(res.data);
//     } catch (err: any) {
//       toast.error(err.response?.data?.detail || 'Failed to load content');
//     } finally {
//       setContentLoading(false);
//     }
//   };

//   const handleTopicClick = (topic: Topic) => {
//     if (!course) return;
//     setActiveTopic(topic);
//     fetchTopicContent(course.id, topic.id);
//     /* Auto-close drawer on mobile after selection */
//     setSidebarOpen(false);
//   };

//   /* ── Mark complete ── */
//   const markComplete = async (topicId: number) => {
//     if (!course) return;
//     try {
//       const res = await enrollmentsApi.markProgress(topicId, true);
//       setCompletedTopics(prev => new Set([...prev, topicId]));
//       toast.success(`Progress: ${res.data.progress_pct}%`);
//       if (res.data.progress_pct >= 100) {
//         toast.success('🎉 Course completed! Certificate issued!', { duration: 5000 });
//       }
//       /* Advance to next topic */
//       for (const lesson of course.lessons) {
//         const idx = lesson.topics.findIndex(t => t.id === topicId);
//         if (idx !== -1 && idx < lesson.topics.length - 1) {
//           handleTopicClick(lesson.topics[idx + 1]);
//           return;
//         }
//       }
//     } catch {
//       toast.error('Could not save progress');
//     }
//   };

//   /* ── AI chat ── */
//   const sendAiMessage = async () => {
//     if (!aiInput.trim() || aiLoading) return;
//     const userMsg: AiMsg = { role: 'user', content: aiInput };
//     setAiMessages(prev => [...prev, userMsg]);
//     setAiInput('');
//     setAiLoading(true);
//     try {
//       const res = await aiApi.chat({ message: aiInput, history: aiMessages, course_id: course?.id });
//       setAiMessages(prev => [...prev, { role: 'assistant', content: res.data.reply }]);
//     } catch {
//       setAiMessages(prev => [
//         ...prev,
//         { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' },
//       ]);
//     } finally {
//       setAiLoading(false);
//       setTimeout(() => aiEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
//     }
//   };

//   const handleAiKey = (e: KeyboardEvent<HTMLInputElement>) => {
//     if (e.key === 'Enter') sendAiMessage();
//   };

//   const toggleLesson = (idx: number) => {
//     setOpenLessons(prev => {
//       const s = new Set(prev);
//       s.has(idx) ? s.delete(idx) : s.add(idx);
//       return s;
//     });
//   };

//   /* ═══════════════════════════════════════════
//      Sidebar / drawer content — the timeline
//      ═══════════════════════════════════════════ */
//   const SidebarTimeline = () => (
//     <div className="learn-lesson-list">
//       {course?.lessons.map((lesson, li) => {
//         const isOpen      = openLessons.has(li);
//         const hasActive   = lesson.topics.some(t => t.id === activeTopic?.id);
//         const topicCount  = lesson.topics.length;

//         return (
//           <div
//             key={lesson.id}
//             className={`lesson-group${isOpen ? ' open' : ''}${hasActive ? ' has-active' : ''}`}
//           >
//             {/* Lesson header row */}
//             <div
//               className="lesson-group-header"
//               onClick={() => toggleLesson(li)}
//               role="button"
//               tabIndex={0}
//               onKeyDown={e => e.key === 'Enter' && toggleLesson(li)}
//               aria-expanded={isOpen}
//             >
//               <span className="lesson-num-circle" aria-hidden="true">
//                 {li + 1}
//               </span>
//               <span className="lesson-group-title">{lesson.title}</span>
//               <i className="bi bi-chevron-down lesson-group-chevron" aria-hidden="true" />
//             </div>

//             {/* Topic timeline — only rendered when lesson is open */}
//             {isOpen && (
//               <div className="topic-timeline" role="list" aria-label={`Topics in ${lesson.title}`}>
//                 {lesson.topics.map((topic, ti) => {
//                   const isDone   = completedTopics.has(topic.id);
//                   const isActive = activeTopic?.id === topic.id;
//                   const isLast   = ti === topicCount - 1;

//                   return (
//                     <div
//                       key={topic.id}
//                       className={`topic-row${isActive ? ' is-active' : ''}${isDone ? ' is-done' : ''}`}
//                       onClick={() => handleTopicClick(topic)}
//                       role="listitem"
//                       tabIndex={0}
//                       onKeyDown={e => e.key === 'Enter' && handleTopicClick(topic)}
//                       aria-current={isActive ? 'true' : undefined}
//                     >
//                       {/* Vertical track: dot + line */}
//                       <div className="topic-track" aria-hidden="true">
//                         <div className="topic-dot" />
//                         {!isLast && <div className="topic-line" />}
//                       </div>

//                       {/* Topic text */}
//                       <div className="topic-label">
//                         <div>
//                           {ti + 1}. {topic.title}
//                           {isDone && (
//                             <i
//                               className="bi bi-check-circle-fill ms-1"
//                               style={{ color: 'var(--success, #22c55e)', fontSize: '0.7rem' }}
//                               aria-label="Completed"
//                             />
//                           )}
//                         </div>
//                         {topic.duration_minutes != null && (
//                           <div className="topic-duration">
//                             <i className="bi bi-clock me-1" />
//                             {topic.duration_minutes}m
//                           </div>
//                         )}
//                       </div>
//                     </div>
//                   );
//                 })}
//               </div>
//             )}
//           </div>
//         );
//       })}
//     </div>
//   );

//   /* ── AI panel inner content (shared desktop + mobile drawer) ── */
//   const AiPanelInner = () => (
//     <>
//       <div className="ai-messages">
//         {aiMessages.length === 0 && (
//           <div className="ai-empty">
//             <i className="bi bi-chat-square-dots" />
//             <p>Ask me anything about this course or topic!</p>
//           </div>
//         )}
//         {aiMessages.map((m, i) => (
//           <div key={i} className={`ai-msg ${m.role}`}>{m.content}</div>
//         ))}
//         {aiLoading && (
//           <div className="ai-msg assistant">
//             <span className="spinner-grow spinner-grow-sm text-primary me-1" />
//             Thinking…
//           </div>
//         )}
//         <div ref={aiEndRef} />
//       </div>

//       <div className="ai-input-row">
//         <input
//           type="text"
//           className="form-control form-control-sm"
//           placeholder="Ask a question…"
//           value={aiInput}
//           onChange={e => setAiInput(e.target.value)}
//           onKeyDown={handleAiKey}
//         />
//         <button
//           className="btn btn-sm btn-primary"
//           onClick={sendAiMessage}
//           disabled={aiLoading}
//           aria-label="Send"
//         >
//           <i className="bi bi-send" />
//         </button>
//       </div>
//     </>
//   );

//   /* ── Loading / redirect guard ── */
//   if (loading) return <Spinner />;
//   if (!course)  return null;

//   const progress = course.progress_pct ?? 0;

//   /* ═══════════════════════════════════════════
//      Render
//      ═══════════════════════════════════════════ */
//   return (
//     <>
//       {/* ── Drawer overlay backdrop — mobile only ── */}
//       <div
//         className={`learn-drawer-overlay${sidebarOpen || aiOpen ? ' show' : ''}`}
//         onClick={() => { setSidebarOpen(false); setAiOpen(false); }}
//         aria-hidden="true"
//       />

//       <div className={`learn-root${aiOpen ? ' ai-open' : ''}`}>

//         {/* ─── Mobile top-bar ─── */}
//         <div className="learn-topbar" role="banner">
//           <div className="learn-topbar-left">
//             <button
//               className="learn-topbar-back"
//               onClick={() => navigate(`/courses/${course.slug}`)}
//               aria-label="Back to course"
//             >
//               <i className="bi bi-arrow-left" />
//             </button>
//             <span className="learn-topbar-title">{course.title}</span>
//           </div>

//           <div className="learn-topbar-actions">
//             <button
//               className={`learn-topbar-btn${sidebarOpen ? ' active' : ''}`}
//               onClick={() => { setSidebarOpen(p => !p); setAiOpen(false); }}
//               aria-label="Toggle content list"
//             >
//               <i className="bi bi-list-ul" />
//               Content
//             </button>
//             <button
//               className={`learn-topbar-btn${aiOpen ? ' active' : ''}`}
//               onClick={() => { setAiOpen(p => !p); setSidebarOpen(false); }}
//               aria-label="Toggle AI chat"
//             >
//               <i className="bi bi-robot" />
//               AI
//             </button>
//           </div>
//         </div>

//         {/* ─── Left sidebar (desktop sticky / mobile drawer) ─── */}
//         <aside
//           className={`learn-sidebar${sidebarOpen ? ' open' : ''}`}
//           aria-label="Course content"
//         >
//           {/* Course info — visible on desktop; hidden on mobile (shown in topbar) */}
//           <div className="learn-sidebar-info">
//             <Link
//               to={`/courses/${course.slug}`}
//               className="learn-sidebar-back"
//             >
//               <i className="bi bi-arrow-left" /> Back to course
//             </Link>
//             <p className="learn-sidebar-course-title">{course.title}</p>
//             <div className="learn-progress-bar-wrap">
//               <div
//                 className="learn-progress-bar-fill"
//                 style={{ width: `${progress}%` }}
//                 role="progressbar"
//                 aria-valuenow={progress}
//                 aria-valuemin={0}
//                 aria-valuemax={100}
//               />
//             </div>
//             <span className="learn-progress-label">{progress}% complete</span>
//           </div>

//           {/* Mobile drawer header — "Content" + X */}
//           <div
//             className="learn-drawer-header"
//             style={{
//               /* Only visible on mobile — desktop version uses .learn-sidebar-info */
//               display: 'none',
//             }}
//             id="sidebar-drawer-header"
//           >
//             <span className="learn-drawer-header-title">Content</span>
//             <button
//               className="learn-drawer-close"
//               onClick={() => setSidebarOpen(false)}
//               aria-label="Close content"
//             >
//               <i className="bi bi-x-lg" />
//             </button>
//           </div>

//           <SidebarTimeline />
//         </aside>

//         {/* ─── Main content area ─── */}
//         <main className="learn-main" role="main">
//           <div className="learn-content-scroll">
//             <div className="learn-content-inner">
//               {activeTopic ? (
//                 <>
//                   {/* Topic header */}
//                   <div className="learn-topic-header">
//                     <div>
//                       <h4 className="learn-topic-title">{activeTopic.title}</h4>
//                       {activeTopic.duration_minutes != null && (
//                         <div className="learn-topic-meta">
//                           <i className="bi bi-clock" />
//                           {activeTopic.duration_minutes} min
//                         </div>
//                       )}
//                     </div>

//                     <div className="learn-topic-actions">
//                       {/* Desktop AI button */}
//                       <button
//                         className={`btn btn-sm${aiOpen ? ' btn-primary' : ' btn-outline-primary'}`}
//                         onClick={() => setAiOpen(p => !p)}
//                         aria-pressed={aiOpen}
//                       >
//                         <i className="bi bi-robot me-1" />
//                         Ask AI
//                       </button>
//                     </div>
//                   </div>

//                   {/* Content or spinner */}
//                   {contentLoading ? (
//                     <Spinner />
//                   ) : topicContent ? (
//                     <>
//                       {topicContent.contents?.map((c: TopicContent) => renderContent(c))}

//                       {activeTopic.description && (
//                         <div className="learn-desc-card">
//                           <h6>About this topic</h6>
//                           <p>{activeTopic.description}</p>
//                         </div>
//                       )}

//                       <div className="learn-complete-row">
//                         {completedTopics.has(activeTopic.id) ? (
//                           <div className="learn-done-badge">
//                             <i className="bi bi-check-circle-fill" />
//                             Topic completed!
//                           </div>
//                         ) : (
//                           <button
//                             className="btn btn-success"
//                             onClick={() => markComplete(activeTopic.id)}
//                           >
//                             <i className="bi bi-check-circle me-1" />
//                             Mark as Complete
//                           </button>
//                         )}
//                       </div>
//                     </>
//                   ) : (
//                     <div className="learn-empty-state">
//                       <i className="bi bi-exclamation-circle" />
//                       <h5>No content yet</h5>
//                       <p>Content for this topic hasn't been added yet.</p>
//                     </div>
//                   )}
//                 </>
//               ) : (
//                 <div className="learn-empty-state" style={{ minHeight: '60vh' }}>
//                   <i className="bi bi-play-circle" />
//                   <h5>Select a topic to start learning</h5>
//                   <p>Choose a topic from the sidebar to begin.</p>
//                 </div>
//               )}
//             </div>
//           </div>
//         </main>

//         {/* ─── Right AI panel (desktop: grid column / mobile: drawer) ─── */}
//         <aside
//           className="learn-ai-panel"
//           aria-label="AI assistant"
//           aria-hidden={!aiOpen}
//         >
//           <div className="ai-panel-header">
//             <div className="ai-panel-title">
//               <i className="bi bi-robot" />
//               Intellect AI
//             </div>
//             <button
//               className="btn btn-sm btn-outline-secondary"
//               onClick={() => setAiOpen(false)}
//               aria-label="Close AI panel"
//             >
//               <i className="bi bi-x-lg" />
//             </button>
//           </div>

//           <AiPanelInner />
//         </aside>

//       </div>

//       {/*
//         Mobile sidebar drawer header injection via CSS.
//         We hide/show `.learn-drawer-header` with a media query
//         rather than duplicating the SidebarTimeline component.
//       */}
//       <style>{`
//         @media (max-width: 768px) {
//           #sidebar-drawer-header {
//             display: flex !important;
//           }
//           .learn-sidebar-info {
//             display: none !important;
//           }
//         }
//       `}</style>
//     </>
//   );
// }





// v3
/*
 * LearnPage.tsx
 *
 * CONTENT PROTECTION — WHAT WE DO AND WHY
 * ─────────────────────────────────────────
 * Client-side (this file):
 *   1. All media (video, image, PDF) is fetched through the axios
 *      instance that carries the auth cookie/token.  The resulting
 *      Blob is turned into a short-lived object URL via
 *      URL.createObjectURL().  This URL:
 *        • Is only valid in the current browser tab (not sharable).
 *        • Does NOT appear as a navigable server path in DevTools.
 *        • Is revoked on unmount so it cannot be accessed after navigation.
 *   2. <video> has controlsList="nodownload noremoteplayback"
 *      and disablePictureInPicture.
 *   3. A transparent .media-shield <div> sits over each media element,
 *      intercepting right-click / long-press on mobile ("Save as…").
 *   4. Images have pointer-events:none (CSS) so they cannot be dragged
 *      or right-clicked; the shield handles context-menu suppression.
 *
 * Server-side (required — not done here):
 *   • Every route under /uploads/ must validate the session.
 *     Without this, a user who finds the URL via another means
 *     can still download the file directly.
 *   • Use short-lived signed URLs (e.g. 30-minute expiry) and
 *     return them from the API rather than storing static paths.
 *   • Set  Content-Disposition: inline  (not attachment) and
 *     X-Content-Type-Options: nosniff on file responses.
 *   • Enable HTTP Range support for video so resume works without
 *     loading the entire file into memory.
 */

import {
  useState,
  useEffect,
  useRef,
  useCallback,
  type KeyboardEvent,
} from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { coursesApi, enrollmentsApi, aiApi } from '@/services/api';
import { Course, Topic, TopicContent } from '@/types';
import { Spinner } from '@/components/shared';
import '@/styles/pages/learning/LearnPage.css';

/* ═══════════════════════════════════════════
   Types
   ═══════════════════════════════════════════ */
interface AiMsg {
  role: 'user' | 'assistant';
  content: string;
}

/* ═══════════════════════════════════════════
   Secure media fetching
   ═══════════════════════════════════════════ */

/**
 * Fetch a media URL through the authenticated axios instance and
 * return a Blob object URL.  The server path never reaches the DOM.
 */
async function fetchSecureBlob(url: string): Promise<string> {
  // We use native fetch here with credentials so auth cookies are sent.
  // If your app uses token-based auth, add the Authorization header:
  //   headers: { Authorization: `Bearer ${getToken()}` }
  const res = await fetch(url, { credentials: 'include' });
  if (!res.ok) throw new Error(`Failed to load media (${res.status})`);
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

/* ═══════════════════════════════════════════
   useSecureMedia hook
   Returns { blobUrl, loading, error }
   Revokes previous blob URL automatically.
   ═══════════════════════════════════════════ */
function useSecureMedia(serverUrl: string | null | undefined) {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState<string | null>(null);
  const prevUrl = useRef<string | null>(null);

  useEffect(() => {
    if (!serverUrl) {
      setBlobUrl(null);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);

    fetchSecureBlob(serverUrl)
      .then(blob => {
        if (cancelled) { URL.revokeObjectURL(blob); return; }
        // Revoke the previous blob URL before replacing it
        if (prevUrl.current) URL.revokeObjectURL(prevUrl.current);
        prevUrl.current = blob;
        setBlobUrl(blob);
      })
      .catch(e => {
        if (!cancelled) setError(e.message ?? 'Failed to load');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [serverUrl]);

  // Revoke on unmount
  useEffect(() => () => {
    if (prevUrl.current) URL.revokeObjectURL(prevUrl.current);
  }, []);

  return { blobUrl, loading, error };
}

/* ═══════════════════════════════════════════
   Video resume helpers
   ═══════════════════════════════════════════ */
const VID_KEY = (id: number) => `vid_pos_${id}`;

function saveVideoPosition(id: number, t: number) {
  try { if (t > 2) localStorage.setItem(VID_KEY(id), String(Math.floor(t))); } catch { /* noop */ }
}

function loadVideoPosition(id: number): number {
  try { return Number(localStorage.getItem(VID_KEY(id))) || 0; } catch { return 0; }
}

/* ═══════════════════════════════════════════
   SecureVideoPlayer
   Fetches via auth, resumes, saves position,
   and guards against download/right-click.
   ═══════════════════════════════════════════ */
interface SecureVideoPlayerProps {
  serverUrl: string;
  topicId: number;
}

function SecureVideoPlayer({ serverUrl, topicId }: SecureVideoPlayerProps) {
  const { blobUrl, loading, error } = useSecureMedia(serverUrl);
  const videoRef  = useRef<HTMLVideoElement>(null);
  const saveTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const resumed   = useRef(false);

  // Reset resumed flag when topic changes
  useEffect(() => { resumed.current = false; }, [topicId]);

  const handleMetadata = useCallback(() => {
    if (resumed.current || !videoRef.current) return;
    const saved = loadVideoPosition(topicId);
    if (saved > 0) { videoRef.current.currentTime = saved; resumed.current = true; }
  }, [topicId]);

  const startSaveTimer = useCallback(() => {
    if (saveTimer.current) clearInterval(saveTimer.current);
    saveTimer.current = setInterval(() => {
      if (videoRef.current) saveVideoPosition(topicId, videoRef.current.currentTime);
    }, 5000);
  }, [topicId]);

  const stopSaveTimer = useCallback(() => {
    if (saveTimer.current) { clearInterval(saveTimer.current); saveTimer.current = null; }
    if (videoRef.current) saveVideoPosition(topicId, videoRef.current.currentTime);
  }, [topicId]);

  const handleEnded = useCallback(() => {
    stopSaveTimer();
    try { localStorage.removeItem(VID_KEY(topicId)); } catch { /* noop */ }
  }, [topicId, stopSaveTimer]);

  useEffect(() => () => { if (saveTimer.current) clearInterval(saveTimer.current); }, []);

  if (loading) {
    return (
      <div className="media-loading">
        <span className="spinner-border spinner-border-sm text-primary" />
        Loading video…
      </div>
    );
  }

  if (error) {
    return (
      <div className="media-loading" style={{ flexDirection: 'column', gap: '0.5rem' }}>
        <i className="bi bi-exclamation-circle text-danger" style={{ fontSize: '1.5rem' }} />
        <span style={{ fontSize: '0.82rem' }}>Could not load video. Please try again.</span>
      </div>
    );
  }

  if (!blobUrl) return null;

  return (
    <div className="learn-video-wrap">
      {/* Shield intercepts right-click / long-press. Video controls are
          rendered in a higher browser layer and remain fully functional. */}
      <div
        className="media-shield"
        onContextMenu={e => e.preventDefault()}
        onDragStart={e => e.preventDefault()}
        aria-hidden="true"
      />
      <video
        ref={videoRef}
        src={blobUrl}
        controls
        controlsList="nodownload noremoteplayback"
        disablePictureInPicture
        playsInline
        onLoadedMetadata={handleMetadata}
        onPlay={startSaveTimer}
        onPause={stopSaveTimer}
        onEnded={handleEnded}
        onContextMenu={e => e.preventDefault()}
      />
    </div>
  );
}

/* ═══════════════════════════════════════════
   SecureImage
   ═══════════════════════════════════════════ */
function SecureImage({ serverUrl, alt }: { serverUrl: string; alt?: string }) {
  const { blobUrl, loading, error } = useSecureMedia(serverUrl);

  if (loading) {
    return (
      <div className="media-loading" style={{ aspectRatio: '16/9' }}>
        <span className="spinner-border spinner-border-sm text-primary" />
        Loading image…
      </div>
    );
  }

  if (error || !blobUrl) return null;

  return (
    <div
      className="learn-image-wrap"
      onContextMenu={e => e.preventDefault()}
      aria-label={alt}
    >
      <div className="media-shield" onContextMenu={e => e.preventDefault()} aria-hidden="true" />
      <img
        src={blobUrl}
        alt={alt || ''}
        draggable={false}
        onDragStart={e => e.preventDefault()}
      />
    </div>
  );
}

/* ═══════════════════════════════════════════
   SecurePdf — renders in an iframe via blob URL
   ═══════════════════════════════════════════ */
function SecurePdf({ serverUrl, title }: { serverUrl: string; title?: string }) {
  const { blobUrl, loading, error } = useSecureMedia(serverUrl);

  if (loading) {
    return (
      <div className="media-loading">
        <span className="spinner-border spinner-border-sm text-primary" />
        Loading PDF…
      </div>
    );
  }

  if (error || !blobUrl) {
    return (
      <div className="media-loading">
        <i className="bi bi-file-earmark-pdf text-danger" style={{ fontSize: '1.5rem' }} />
        Could not load PDF.
      </div>
    );
  }

  return (
    <div className="learn-pdf-wrap">
      {/* No download link exposed — only the blob URL iframe */}
      <iframe
        src={blobUrl}
        className="learn-pdf-viewer"
        title={title || 'PDF Document'}
        // Sandbox prevents the iframe from navigating to the blob URL
        // in a new tab (some browsers allow this; sandbox blocks it).
        sandbox="allow-same-origin allow-scripts"
      />
    </div>
  );
}

/* ═══════════════════════════════════════════
   renderContent
   ═══════════════════════════════════════════ */
function renderContent(content: TopicContent) {
  // Resolve the server-side path.  We intentionally do NOT put this
  // URL anywhere in the DOM — it is only passed to the secure fetchers.
  const serverUrl = content.url ||
    (content.file_path
      ? `${(import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '')}/uploads/courses/content/${content.file_path}`
      : null);

  switch (content.content_type) {
    case 'video':
      return serverUrl
        ? <SecureVideoPlayer key={content.id} serverUrl={serverUrl} topicId={content.id} />
        : null;

    case 'pdf':
      return serverUrl
        ? <SecurePdf key={content.id} serverUrl={serverUrl} title={content.title} />
        : null;

    case 'image':
      return serverUrl
        ? <SecureImage key={content.id} serverUrl={serverUrl} alt={content.title} />
        : null;

    case 'ppt':
      // PPT files are download-only — show a card with no direct path in the DOM
      return serverUrl ? (
        <div key={content.id} className="learn-file-card">
          <i className="bi bi-file-earmark-slides text-danger learn-file-icon" />
          <div className="learn-file-info">
            <div className="learn-file-name">{content.title || 'Presentation'}</div>
            <div className="learn-file-type">PowerPoint / Slides</div>
          </div>
          {/* Download via fetch to avoid exposing raw URL — simple anchor still fine
              for PPT since these are already download-type files */}
          <a
            href={serverUrl}
            download
            className="btn btn-sm btn-primary ms-auto"
            onClick={e => {
              // Prevent the anchor from appearing in browser history / address bar
              e.preventDefault();
              fetchSecureBlob(serverUrl).then(blob => {
                const a = document.createElement('a');
                a.href = blob;
                a.download = content.title || 'presentation.pptx';
                a.click();
                setTimeout(() => URL.revokeObjectURL(blob), 10000);
              }).catch(() => toast.error('Download failed'));
            }}
          >
            <i className="bi bi-download me-1" /> Download
          </a>
        </div>
      ) : null;

    case 'audio':
      // Audio: blob URL via hook — but audio is less sensitive so we
      // render inline without a shield (seeking UX matters more).
      return serverUrl ? (
        <AudioPlayer key={content.id} serverUrl={serverUrl} />
      ) : null;

    case 'text':
      return (
        <div
          key={content.id}
          className="learn-prose"
          dangerouslySetInnerHTML={{ __html: content.body || '' }}
        />
      );

    default:
      // Generic file: no direct URL in DOM — download via blob
      return serverUrl ? (
        <div key={content.id} style={{ marginBottom: '1.25rem' }}>
          <button
            className="btn btn-outline-primary"
            onClick={() => {
              fetchSecureBlob(serverUrl).then(blob => {
                const a = document.createElement('a');
                a.href = blob;
                a.download = content.title || 'file';
                a.click();
                setTimeout(() => URL.revokeObjectURL(blob), 10000);
              }).catch(() => toast.error('Download failed'));
            }}
          >
            <i className="bi bi-file-earmark me-1" />
            Open {content.title || 'File'}
          </button>
        </div>
      ) : null;
  }
}

/* ─── AudioPlayer helper ─── */
function AudioPlayer({ serverUrl }: { serverUrl: string }) {
  const { blobUrl, loading } = useSecureMedia(serverUrl);
  if (loading) return <div className="media-loading"><span className="spinner-border spinner-border-sm text-primary" /> Loading audio…</div>;
  if (!blobUrl) return null;
  return (
    <div style={{ marginBottom: '1.25rem' }}>
      <audio controls className="w-100">
        <source src={blobUrl} />
      </audio>
    </div>
  );
}

/* ═══════════════════════════════════════════
   LearnPage (main component)
   ═══════════════════════════════════════════ */
export default function LearnPage() {
  const { slug }  = useParams<{ slug: string }>();
  const navigate  = useNavigate();

  /* ── Core state ── */
  const [course,          setCourse]          = useState<Course | null>(null);
  const [activeTopic,     setActiveTopic]     = useState<Topic | null>(null);
  const [topicContent,    setTopicContent]    = useState<any>(null);
  const [loading,         setLoading]         = useState(true);
  const [contentLoading,  setContentLoading]  = useState(false);
  const [openLessons,     setOpenLessons]     = useState<Set<number>>(new Set([0]));
  const [completedTopics, setCompletedTopics] = useState<Set<number>>(new Set());

  /* ── Panel state ── */
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [aiOpen,      setAiOpen]      = useState(false);

  /* ── AI chat ── */
  const [aiMessages, setAiMessages] = useState<AiMsg[]>([]);
  const [aiInput,    setAiInput]    = useState('');
  const [aiLoading,  setAiLoading]  = useState(false);
  const aiEndRef = useRef<HTMLDivElement>(null);

  /* ── Lock body scroll when a mobile drawer is open ── */
  useEffect(() => {
    document.body.style.overflow = (sidebarOpen || aiOpen) ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [sidebarOpen, aiOpen]);

  /* ── Load course ── */
  useEffect(() => {
    if (!slug) return;
    coursesApi.get(slug)
      .then(r => {
        const c: Course = r.data;
        if (!c.is_enrolled) { navigate(`/courses/${slug}`); return; }
        setCourse(c);
        // Seed completed topics from server data
        const done = new Set<number>();
        (c.lessons ?? []).forEach((l: any) =>
          (l.topics ?? []).forEach((t: any) => { if (t.is_completed) done.add(t.id); })
        );
        setCompletedTopics(done);
        // Auto-select first topic
        if (c.lessons?.length > 0 && c.lessons[0].topics?.length > 0) {
          const first = c.lessons[0].topics[0];
          setActiveTopic(first);
          fetchTopicContent(c.id, first.id);
        }
      })
      .catch(() => navigate('/explore'))
      .finally(() => setLoading(false));
  }, [slug]);

  const fetchTopicContent = async (courseId: number, topicId: number) => {
    setContentLoading(true);
    try {
      const res = await coursesApi.getTopicContent(courseId, topicId);
      setTopicContent(res.data);
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Failed to load content');
    } finally {
      setContentLoading(false);
    }
  };

  const handleTopicClick = (topic: Topic) => {
    if (!course) return;
    setActiveTopic(topic);
    fetchTopicContent(course.id, topic.id);
    setSidebarOpen(false); // close drawer on mobile after selection
  };

  /* ── Mark complete — updates progress live ── */
  const markComplete = async (topicId: number) => {
    if (!course) return;
    try {
      const res = await enrollmentsApi.markProgress(topicId, true);
      const newPct: number = res.data.progress_pct ?? 0;

      // 1. Mark topic as done in local set
      setCompletedTopics(prev => new Set([...prev, topicId]));

      // 2. Update course.progress_pct so sidebar progress bar updates immediately
      setCourse(prev =>
        prev ? { ...prev, progress_pct: newPct } : prev
      );

      toast.success(`Progress: ${newPct}%`);

      if (newPct >= 100) {
        toast.success('🎉 Course completed! Certificate issued!', { duration: 5000 });
      }

      // 3. Advance to next topic
      for (const lesson of course.lessons) {
        const idx = lesson.topics.findIndex((t: any) => t.id === topicId);
        if (idx !== -1 && idx < lesson.topics.length - 1) {
          handleTopicClick(lesson.topics[idx + 1]);
          return;
        }
      }
    } catch {
      toast.error('Could not save progress');
    }
  };

  /* ── AI chat ── */
  const sendAiMessage = async () => {
    if (!aiInput.trim() || aiLoading) return;
    const userMsg: AiMsg = { role: 'user', content: aiInput };
    setAiMessages(prev => [...prev, userMsg]);
    setAiInput('');
    setAiLoading(true);
    try {
      const res = await aiApi.chat({ message: aiInput, history: aiMessages, course_id: course?.id });
      setAiMessages(prev => [...prev, { role: 'assistant', content: res.data.reply }]);
    } catch {
      setAiMessages(prev => [
        ...prev,
        { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' },
      ]);
    } finally {
      setAiLoading(false);
      setTimeout(() => aiEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }
  };

  const handleAiKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') sendAiMessage();
  };

  const toggleLesson = (idx: number) => {
    setOpenLessons(prev => {
      const s = new Set(prev);
      s.has(idx) ? s.delete(idx) : s.add(idx);
      return s;
    });
  };

  /* ── Guards ── */
  if (loading) return <Spinner />;
  if (!course)  return null;

  const progress = course.progress_pct ?? 0;

  /* ═══════════════════════════════════════════
     Timeline sidebar content
     ═══════════════════════════════════════════ */
  const SidebarTimeline = () => (
    <div className="learn-lesson-list">
      {(course.lessons ?? []).map((lesson: any, li: number) => {
        const isOpen    = openLessons.has(li);
        const hasActive = lesson.topics?.some((t: any) => t.id === activeTopic?.id);

        return (
          <div
            key={lesson.id}
            className={`lesson-group${isOpen ? ' open' : ''}${hasActive ? ' has-active' : ''}`}
          >
            <div
              className="lesson-group-header"
              onClick={() => toggleLesson(li)}
              role="button"
              tabIndex={0}
              onKeyDown={e => e.key === 'Enter' && toggleLesson(li)}
              aria-expanded={isOpen}
            >
              <span className="lesson-num-circle" aria-hidden="true">{li + 1}</span>
              <span className="lesson-group-title">{lesson.title}</span>
              <i className="bi bi-chevron-down lesson-group-chevron" aria-hidden="true" />
            </div>

            {isOpen && (
              <div className="topic-timeline" role="list">
                {(lesson.topics ?? []).map((topic: any, ti: number) => {
                  const isDone   = completedTopics.has(topic.id);
                  const isActive = activeTopic?.id === topic.id;
                  const isLast   = ti === lesson.topics.length - 1;

                  return (
                    <div
                      key={topic.id}
                      className={`topic-row${isActive ? ' is-active' : ''}${isDone ? ' is-done' : ''}`}
                      onClick={() => handleTopicClick(topic)}
                      role="listitem"
                      tabIndex={0}
                      onKeyDown={e => e.key === 'Enter' && handleTopicClick(topic)}
                      aria-current={isActive ? 'true' : undefined}
                    >
                      <div className="topic-track" aria-hidden="true">
                        <div className="topic-dot" />
                        {!isLast && <div className="topic-line" />}
                      </div>
                      <div className="topic-label">
                        <div>
                          {ti + 1}. {topic.title}
                          {isDone && (
                            <i
                              className="bi bi-check-circle-fill ms-1"
                              style={{ color: 'var(--success, #22c55e)', fontSize: '0.7rem' }}
                            />
                          )}
                        </div>
                        {topic.duration_minutes != null && (
                          <div className="topic-duration">
                            <i className="bi bi-clock me-1" />
                            {topic.duration_minutes}m
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );

  /* ── AI panel inner ── */
  const AiPanelInner = () => (
    <>
      <div className="ai-messages">
        {aiMessages.length === 0 && (
          <div className="ai-empty">
            <i className="bi bi-chat-square-dots" />
            <p>Ask me anything about this course or topic!</p>
          </div>
        )}
        {aiMessages.map((m, i) => (
          <div key={i} className={`ai-msg ${m.role}`}>{m.content}</div>
        ))}
        {aiLoading && (
          <div className="ai-msg assistant">
            <span className="spinner-grow spinner-grow-sm text-primary me-1" />
            Thinking…
          </div>
        )}
        <div ref={aiEndRef} />
      </div>

      <div className="ai-input-row">
        <input
          type="text"
          className="form-control form-control-sm"
          placeholder="Ask a question…"
          value={aiInput}
          onChange={e => setAiInput(e.target.value)}
          onKeyDown={handleAiKey}
        />
        <button
          className="btn btn-sm btn-primary"
          onClick={sendAiMessage}
          disabled={aiLoading}
          aria-label="Send"
        >
          <i className="bi bi-send" />
        </button>
      </div>
    </>
  );

  /* ═══════════════════════════════════════════
     Render
     ═══════════════════════════════════════════ */
  return (
    <>
      {/* Mobile overlay */}
      <div
        className={`learn-drawer-overlay${sidebarOpen || aiOpen ? ' show' : ''}`}
        onClick={() => { setSidebarOpen(false); setAiOpen(false); }}
        aria-hidden="true"
      />

      <div className={`learn-root${aiOpen ? ' ai-open' : ''}`}>

        {/* ── Mobile top-bar ── */}
        <div className="learn-topbar">
          <div className="learn-topbar-left">
            <button
              className="learn-topbar-back"
              onClick={() => navigate(`/courses/${course.slug}`)}
              aria-label="Back"
            >
              <i className="bi bi-arrow-left" />
            </button>
            <span className="learn-topbar-title">{course.title}</span>
          </div>
          <div className="learn-topbar-actions">
            <button
              className={`learn-topbar-btn${sidebarOpen ? ' active' : ''}`}
              onClick={() => { setSidebarOpen(p => !p); setAiOpen(false); }}
            >
              <i className="bi bi-list-ul" /> Content
            </button>
            <button
              className={`learn-topbar-btn${aiOpen ? ' active' : ''}`}
              onClick={() => { setAiOpen(p => !p); setSidebarOpen(false); }}
            >
              <i className="bi bi-robot" /> AI
            </button>
          </div>
        </div>

        {/* ── Left sidebar ── */}
        <aside
          className={`learn-sidebar${sidebarOpen ? ' open' : ''}`}
          aria-label="Course content"
        >
          {/* Mobile drawer header */}
          <div className="learn-drawer-header">
            <span className="learn-drawer-header-title">Content</span>
            <button
              className="learn-drawer-close"
              onClick={() => setSidebarOpen(false)}
              aria-label="Close"
            >
              <i className="bi bi-x-lg" />
            </button>
          </div>

          {/* Desktop course info */}
          <div className="learn-sidebar-info">
            <Link to={`/courses/${course.slug}`} className="learn-sidebar-back">
              <i className="bi bi-arrow-left" /> Back to course
            </Link>
            <p className="learn-sidebar-course-title">{course.title}</p>
            <div className="learn-progress-bar-wrap">
              <div
                className="learn-progress-bar-fill"
                style={{ width: `${progress}%` }}
                role="progressbar"
                aria-valuenow={progress}
                aria-valuemin={0}
                aria-valuemax={100}
              />
            </div>
            <span className="learn-progress-label">{progress}% complete</span>
          </div>

          <SidebarTimeline />
        </aside>

        {/* ── Main content ── */}
        <main className="learn-main">
          <div className="learn-content-scroll">
            <div className="learn-content-inner">
              {activeTopic ? (
                <>
                  <div className="learn-topic-header">
                    <div>
                      <h4 className="learn-topic-title">{activeTopic.title}</h4>
                      {activeTopic.duration_minutes != null && (
                        <div className="learn-topic-meta">
                          <i className="bi bi-clock" />
                          {activeTopic.duration_minutes} min
                        </div>
                      )}
                    </div>
                    <div className="learn-topic-actions">
                      <button
                        className={`btn btn-sm${aiOpen ? ' btn-primary' : ' btn-outline-primary'}`}
                        onClick={() => setAiOpen(p => !p)}
                      >
                        <i className="bi bi-robot me-1" /> Ask AI
                      </button>
                    </div>
                  </div>

                  {contentLoading ? (
                    <Spinner />
                  ) : topicContent ? (
                    <>
                      {(topicContent.contents ?? []).map((c: TopicContent) => renderContent(c))}

                      {activeTopic.description && (
                        <div className="learn-desc-card">
                          <h6>About this topic</h6>
                          <p>{activeTopic.description}</p>
                        </div>
                      )}

                      <div className="learn-complete-row">
                        {completedTopics.has(activeTopic.id) ? (
                          <div className="learn-done-badge">
                            <i className="bi bi-check-circle-fill" /> Topic completed!
                          </div>
                        ) : (
                          <button
                            className="btn btn-success"
                            onClick={() => markComplete(activeTopic.id)}
                          >
                            <i className="bi bi-check-circle me-1" /> Mark as Complete
                          </button>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="learn-empty-state">
                      <i className="bi bi-exclamation-circle" />
                      <h5>No content yet</h5>
                      <p>Content for this topic hasn't been added yet.</p>
                    </div>
                  )}
                </>
              ) : (
                <div className="learn-empty-state" style={{ minHeight: '60vh' }}>
                  <i className="bi bi-play-circle" />
                  <h5>Select a topic to start learning</h5>
                  <p>Choose a topic from the sidebar to begin.</p>
                </div>
              )}
            </div>
          </div>
        </main>

        {/* ── Right AI panel ── */}
        <aside className="learn-ai-panel" aria-label="AI assistant" aria-hidden={!aiOpen}>
          <div className="ai-panel-header">
            <div className="ai-panel-title">
              <i className="bi bi-robot" /> Intellect AI
            </div>
            <button
              className="btn btn-sm btn-outline-secondary"
              onClick={() => setAiOpen(false)}
              aria-label="Close AI"
            >
              <i className="bi bi-x-lg" />
            </button>
          </div>
          <AiPanelInner />
        </aside>

      </div>
    </>
  );
}

