// import { useState, useEffect } from 'react';
// import { useParams, useNavigate, Link } from 'react-router-dom';
// import toast from 'react-hot-toast';
// import { coursesApi, enrollmentsApi, paymentsApi } from '@/services/api';
// import { Course } from '@/types';
// import { Spinner, RatingStars, StatusBadge, Avatar } from '@/components/shared';
// import { useAuth } from '@/context/AuthContext';

// export default function CourseDetail() {
//   const { slug } = useParams<{ slug: string }>();
//   const { user } = useAuth();
//   const navigate = useNavigate();
//   const [course, setCourse] = useState<Course | null>(null);
//   const [loading, setLoading] = useState(true);
//   const [enrolling, setEnrolling] = useState(false);
//   const [openLesson, setOpenLesson] = useState<number | null>(0);
//   const [discountCode, setDiscountCode] = useState('');
//   const [discountInfo, setDiscountInfo] = useState<any>(null);
//   const [checking, setChecking] = useState(false);

//   useEffect(() => {
//     if (!slug) return;
//     coursesApi.get(slug).then(r => setCourse(r.data)).catch(() => navigate('/explore')).finally(() => setLoading(false));
//   }, [slug]);

//   const handleEnroll = async () => {
//     if (!user) { navigate('/auth/signin'); return; }
//     if (!course) return;
//     setEnrolling(true);
//     try {
//       if (course.fee > 0) {
//         const finalPrice = discountInfo?.final_price ?? course.fee;
//         const res = await paymentsApi.initiate({
//           course_id: course.id,
//           payment_type: course.payment_type,
//           discount_code: discountCode || undefined,
//         });
//         window.location.href = res.data.payment_url;
//       } else {
//         await enrollmentsApi.enroll(course.id);
//         toast.success('Enrolled successfully!');
//         navigate(`/learn/${course.slug}`);
//       }
//     } catch (err: any) {
//       toast.error(err.response?.data?.detail || 'Enrollment failed');
//     } finally { setEnrolling(false); }
//   };

//   const checkDiscount = async () => {
//     if (!discountCode || !course) return;
//     setChecking(true);
//     try {
//       const res = await paymentsApi.validateDiscount({ code: discountCode, course_id: course.id });
//       setDiscountInfo(res.data);
//       if (res.data.valid) toast.success(res.data.message);
//       else toast.error(res.data.message);
//     } catch { toast.error('Could not validate code'); }
//     finally { setChecking(false); }
//   };

//   if (loading) return <Spinner />;
//   if (!course) return null;

//   const displayPrice = discountInfo?.valid ? discountInfo.final_price : course.fee;

//   return (
//     <div className="fade-in">
//       {/* Breadcrumb */}
//       <nav className="mb-3">
//         <ol className="breadcrumb">
//           <li className="breadcrumb-item"><Link to="/">Home</Link></li>
//           <li className="breadcrumb-item"><Link to="/explore">Courses</Link></li>
//           <li className="breadcrumb-item active">{course.title}</li>
//         </ol>
//       </nav>

//       <div className="row g-4">
//         {/* Main */}
//         <div className="col-lg-8">
//           {/* Header */}
//           <div className="mb-4">
//             <div className="d-flex align-items-center gap-2 mb-2 flex-wrap">
//               {course.categories.map(c => <span key={c.id} className="badge bg-primary-light text-primary" style={{ fontSize: '0.7rem' }}>{c.title}</span>)}
//               <span className={`badge-level ${course.level}`}>{course.level}</span>
//               {course.featured && <span className="badge bg-warning text-dark" style={{ fontSize: '0.7rem' }}>Featured</span>}
//             </div>
//             <h1 className="fw-bold mb-2" style={{ fontSize: '1.75rem' }}>{course.title}</h1>
//             {course.short_description && <p className="text-muted mb-3">{course.short_description}</p>}
//             <div className="d-flex align-items-center gap-3 flex-wrap mb-3">
//               {course.avg_rating && (
//                 <div className="d-flex align-items-center gap-1">
//                   <span className="fw-700 text-warning">{course.avg_rating}</span>
//                   <RatingStars rating={course.avg_rating} />
//                 </div>
//               )}
//               <span className="text-muted" style={{ fontSize: '0.8rem' }}><i className="bi bi-people me-1" />{course.enrolled_count} enrolled</span>
//               <span className="text-muted" style={{ fontSize: '0.8rem' }}><i className="bi bi-book me-1" />{course.lessons_count} lessons</span>
//               {course.duration_weeks && <span className="text-muted" style={{ fontSize: '0.8rem' }}><i className="bi bi-clock me-1" />{course.duration_weeks} weeks</span>}
//               <span className="text-muted" style={{ fontSize: '0.8rem' }}><i className="bi bi-translate me-1" />{course.lang?.toUpperCase()}</span>
//             </div>
//             {course.creator && (
//               <div className="d-flex align-items-center gap-2">
//                 <Avatar image={course.creator.image} name={course.creator.name} size={36} />
//                 <div>
//                   <div className="fw-600" style={{ fontSize: '0.875rem' }}>{course.creator.name}</div>
//                   <div className="text-muted" style={{ fontSize: '0.72rem' }}>Course Creator</div>
//                 </div>
//               </div>
//             )}
//           </div>

//           {/* Tutors */}
//           {course.tutors && course.tutors.length > 0 && (
//             <div className="card mb-4 p-3">
//               <h6 className="fw-700 mb-2"><i className="bi bi-person-video3 me-2 text-primary" />Assigned Instructor{course.tutors.length > 1 ? 's' : ''}</h6>
//               <div className="d-flex gap-3 flex-wrap">
//                 {course.tutors.map(t => (
//                   <div key={t.id} className="d-flex align-items-center gap-2">
//                     <Avatar image={t.image} name={t.name} size={36} />
//                     <div>
//                       <div className="fw-600" style={{ fontSize: '0.8rem' }}>{t.name}</div>
//                       <div className="text-muted" style={{ fontSize: '0.7rem' }}>Instructor</div>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}

//           {/* What you'll learn */}
//           {course.what_you_learn && (
//             <div className="card mb-4 p-4">
//               <h5 className="fw-700 mb-3"><i className="bi bi-lightbulb me-2 text-warning" />What You'll Learn</h5>
//               <div className="row g-2">
//                 {course.what_you_learn.split('\n').filter(Boolean).map((item, i) => (
//                   <div key={i} className="col-sm-6 d-flex align-items-start gap-2">
//                     <i className="bi bi-check-circle-fill text-success mt-1" style={{ flexShrink: 0 }} />
//                     <span style={{ fontSize: '0.875rem' }}>{item}</span>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}

//           {/* Curriculum */}
//           <div className="card mb-4">
//             <div className="card-header-custom">
//               <h5 className="fw-700 mb-0"><i className="bi bi-list-ol me-2 text-primary" />Curriculum</h5>
//               <span className="text-muted" style={{ fontSize: '0.8rem' }}>{course.lessons_count} lessons · {course.topics_count} topics</span>
//             </div>
//             <div>
//               {course.lessons.map((lesson, li) => (
//                 <div key={lesson.id}>
//                   <button
//                     className="lesson-header w-100 text-start border-0 bg-transparent"
//                     onClick={() => setOpenLesson(openLesson === li ? null : li)}
//                   >
//                     <span><i className="bi bi-collection me-2 text-primary" />{lesson.title}</span>
//                     <span className="d-flex align-items-center gap-2">
//                       <span className="text-muted" style={{ fontSize: '0.75rem' }}>{lesson.topics.length} topics</span>
//                       <i className={`bi ${openLesson === li ? 'bi-chevron-up' : 'bi-chevron-down'} text-muted`} />
//                     </span>
//                   </button>
//                   {openLesson === li && lesson.topics.map(topic => (
//                     <div key={topic.id} className="topic-item">
//                       <i className={`bi ${topic.is_free_preview ? 'bi-play-circle text-primary' : 'bi-lock text-muted'}`} />
//                       <span className="flex-1">{topic.title}</span>
//                       {topic.duration_minutes && <span className="text-muted" style={{ fontSize: '0.7rem' }}>{topic.duration_minutes}m</span>}
//                       {topic.is_free_preview && <span className="badge bg-success-light text-success" style={{ fontSize: '0.65rem' }}>Preview</span>}
//                     </div>
//                   ))}
//                 </div>
//               ))}
//             </div>
//           </div>

//           {/* Requirements */}
//           {course.requirements && (
//             <div className="card mb-4 p-4">
//               <h5 className="fw-700 mb-3">Requirements</h5>
//               <ul className="mb-0" style={{ fontSize: '0.875rem', paddingLeft: '1.25rem' }}>
//                 {course.requirements.split('\n').filter(Boolean).map((r, i) => <li key={i}>{r}</li>)}
//               </ul>
//             </div>
//           )}
//         </div>

//         {/* Sidebar — enroll card */}
//         <div className="col-lg-4">
//           <div className="card sticky-top" style={{ top: 'calc(var(--nav-height) + 1rem)' }}>
//             {/* Preview video / thumbnail */}
//             {course.preview_video ? (
//               <div className="video-wrapper" style={{ borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0' }}>
//                 <video controls poster={course.thumbnail ? `/uploads/courses/thumbnails/${course.thumbnail}` : undefined} style={{ borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0' }}>
//                   <source src={course.preview_video} />
//                 </video>
//               </div>
//             ) : course.thumbnail ? (
//               <img src={`/uploads/courses/thumbnails/${course.thumbnail}`} alt={course.title} style={{ width: '100%', height: 200, objectFit: 'cover', borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0' }} />
//             ) : (
//               <div style={{ height: 180, background: 'linear-gradient(135deg, var(--primary-light), #e8f4fd)', borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
//                 <i className="bi bi-play-circle text-primary" style={{ fontSize: '3rem' }} />
//               </div>
//             )}

//             <div className="p-4">
//               {/* Price */}
//               <div className="mb-3">
//                 {course.fee > 0 ? (
//                   <>
//                     <div className="d-flex align-items-baseline gap-2">
//                       <span className="fw-bold" style={{ fontSize: '1.75rem', color: 'var(--primary)' }}>₦{displayPrice.toLocaleString()}</span>
//                       {discountInfo?.valid && <span className="text-muted text-decoration-line-through" style={{ fontSize: '1rem' }}>₦{course.fee.toLocaleString()}</span>}
//                     </div>
//                     {discountInfo?.valid && <div className="text-success fw-600" style={{ fontSize: '0.8rem' }}>You save ₦{discountInfo.savings.toLocaleString()}</div>}
//                     <div className="text-muted" style={{ fontSize: '0.75rem' }}>{course.payment_type === 'one_time' ? 'One-time payment' : course.payment_type === 'subscription' ? `${course.subscription_interval}ly subscription` : 'Pay as you go'}</div>
//                   </>
//                 ) : (
//                   <span className="badge bg-success" style={{ fontSize: '1rem', padding: '0.5rem 1rem' }}>Free</span>
//                 )}
//               </div>

//               {/* Discount code */}
//               {course.fee > 0 && !course.is_enrolled && (
//                 <div className="mb-3">
//                   <div className="d-flex gap-2">
//                     <input type="text" className="form-control form-control-sm" placeholder="Discount code" value={discountCode} onChange={e => setDiscountCode(e.target.value.toUpperCase())} />
//                     <button className="btn btn-sm btn-outline-primary" onClick={checkDiscount} disabled={checking}>
//                       {checking ? <span className="spinner-border spinner-border-sm" /> : 'Apply'}
//                     </button>
//                   </div>
//                 </div>
//               )}

//               {/* CTA */}
//               {course.is_enrolled ? (
//                 <Link to={`/learn/${course.slug}`} className="btn btn-success w-100 py-2 fw-600 btn-icon-start mb-3">
//                   <i className="bi bi-play-fill" /> Continue Learning
//                   {course.progress_pct > 0 && <span className="ms-auto opacity-75">{course.progress_pct}%</span>}
//                 </Link>
//               ) : (
//                 <button className="btn btn-primary w-100 py-2 fw-600 mb-3" onClick={handleEnroll} disabled={enrolling}>
//                   {enrolling ? <><span className="spinner-border spinner-border-sm me-2" />Processing…</> : course.fee > 0 ? `Enroll · ₦${displayPrice.toLocaleString()}` : 'Enroll for Free'}
//                 </button>
//               )}

//               {/* Includes */}
//               <div className="d-flex flex-column gap-2">
//                 {[
//                   { icon: 'bi-collection', text: `${course.lessons_count} lessons` },
//                   { icon: 'bi-file-earmark-play', text: `${course.topics_count} topics` },
//                   ...(course.duration_weeks ? [{ icon: 'bi-clock', text: `${course.duration_weeks} weeks` }] : []),
//                   { icon: 'bi-phone', text: 'Mobile & desktop access' },
//                   { icon: 'bi-award', text: 'Certificate on completion' },
//                 ].map((item, i) => (
//                   <div key={i} className="d-flex align-items-center gap-2 text-muted" style={{ fontSize: '0.8rem' }}>
//                     <i className={`bi ${item.icon} text-primary`} style={{ width: 16 }} />
//                     {item.text}
//                   </div>
//                 ))}
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }




// // v2
// import { useState, useEffect } from 'react';
// import { useParams, useNavigate, useSearchParams, Link } from 'react-router-dom';
// import toast from 'react-hot-toast';
// import { coursesApi, enrollmentsApi, paymentsApi } from '@/services/api';
// import { Course } from '@/types';
// import { Spinner, RatingStars, Avatar } from '@/components/shared';
// import { useAuth } from '@/context/AuthContext';

// /* ─── Helpers ────────────────────────────────────────────── */
// /**
//  * Resolve a backend media path to a fully-qualified URL.
//  *
//  * The backend stores bare filenames (e.g. "abc123.png") or sometimes
//  * prefixed paths ("/uploads/courses/thumbnails/abc123.png"). Either way
//  * we need the API origin prepended so the browser can actually fetch it.
//  */
// function mediaUrl(
//   path: string | null | undefined,
//   folder = 'courses/thumbnails',
// ): string | undefined {
//   if (!path) return undefined;
//   if (path.startsWith('http')) return path;
//   const base = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '');
//   // Already a rooted path — just prepend origin
//   if (path.startsWith('/')) return `${base}${path}`;
//   // Bare filename — build full path
//   return `${base}/uploads/${folder}/${path}`;
// }

// /* ═══════════════════════════════════════════════════════════
//    CourseDetail
//    ═══════════════════════════════════════════════════════════ */
// export default function CourseDetail() {
//   const { slug }          = useParams<{ slug: string }>();
//   const [searchParams]    = useSearchParams();
//   const { user }          = useAuth();
//   const navigate          = useNavigate();

//   const [course,       setCourse]       = useState<Course | null>(null);
//   const [loading,      setLoading]      = useState(true);
//   const [enrolling,    setEnrolling]    = useState(false);
//   const [openLesson,   setOpenLesson]   = useState<number | null>(0);
//   const [discountCode, setDiscountCode] = useState('');
//   const [discountInfo, setDiscountInfo] = useState<any>(null);
//   const [checking,     setChecking]     = useState(false);

//   /* ── Load course ── */
//   useEffect(() => {
//     if (!slug) return;
//     coursesApi
//       .get(slug)
//       .then(r => setCourse(r.data))
//       .catch(() => navigate('/explore'))
//       .finally(() => setLoading(false));
//   }, [slug]);

//   /* ── Handle Paystack callback ──────────────────────────────
//    *
//    * After Paystack processes the payment it redirects back to:
//    *   /courses/<slug>?trxref=<ref>&reference=<ref>
//    *
//    * We detect that and verify the payment server-side, then
//    * show the appropriate outcome without fetching /courses/undefined.
//    */
//   useEffect(() => {
//     const reference = searchParams.get('reference') || searchParams.get('trxref');
//     if (!reference || !course) return;

//     paymentsApi
//       .verify(reference)
//       .then(r => {
//         if (r.data?.status === 'success' || r.data?.paid) {
//           toast.success('Payment successful! You are now enrolled.');
//           // Refresh course so is_enrolled updates
//           coursesApi.get(slug!).then(r2 => setCourse(r2.data));
//         } else {
//           toast.error('Payment could not be verified. Contact support if you were charged.');
//         }
//       })
//       .catch(() => toast.error('Payment verification failed'))
//       // Clean query params so refresh doesn't re-verify
//       .finally(() => navigate(`/courses/${slug}`, { replace: true }));
//   }, [course, searchParams]);

//   /* ── Enroll / pay ── */
//   const handleEnroll = async () => {
//     if (!user)   { navigate('/auth/signin'); return; }
//     if (!course) { return; }

//     setEnrolling(true);
//     try {
//       if (course.fee > 0) {
//         const res = await paymentsApi.initiate({
//           course_id:     course.id,
//           payment_type:  course.payment_type,
//           discount_code: discountCode || undefined,
//           // Tell Paystack where to send the user back.
//           // This MUST include the course slug so we never land on /courses/undefined.
//           callback_url: `${window.location.origin}/courses/${course.slug}`,
//         });
//         // Redirect to Paystack hosted page
//         window.location.href = res.data.payment_url;
//       } else {
//         await enrollmentsApi.enroll(course.id);
//         toast.success('Enrolled successfully!');
//         navigate(`/learn/${course.slug}`);
//       }
//     } catch (err: any) {
//       toast.error(err.response?.data?.detail || 'Enrollment failed');
//     } finally {
//       setEnrolling(false);
//     }
//   };

//   /* ── Discount code ── */
//   const checkDiscount = async () => {
//     if (!discountCode || !course) return;
//     setChecking(true);
//     try {
//       const res = await paymentsApi.validateDiscount({ code: discountCode, course_id: course.id });
//       setDiscountInfo(res.data);
//       if (res.data.valid) toast.success(res.data.message);
//       else toast.error(res.data.message);
//     } catch { toast.error('Could not validate code'); }
//     finally { setChecking(false); }
//   };

//   if (loading) return <Spinner />;
//   if (!course) return null;

//   const displayPrice = discountInfo?.valid ? discountInfo.final_price : course.fee;
//   const thumbSrc     = mediaUrl(course.thumbnail);

//   return (
//     <div className="fade-in">
//       {/* Breadcrumb */}
//       <nav className="mb-3">
//         <ol className="breadcrumb">
//           <li className="breadcrumb-item"><Link to="/">Home</Link></li>
//           <li className="breadcrumb-item"><Link to="/explore">Courses</Link></li>
//           <li className="breadcrumb-item active">{course.title}</li>
//         </ol>
//       </nav>

//       <div className="row g-4">
//         {/* ── Main ── */}
//         <div className="col-lg-8">

//           {/* Header */}
//           <div className="mb-4">
//             <div className="d-flex align-items-center gap-2 mb-2 flex-wrap">
//               {(course.categories || []).map((c: any) => (
//                 <span key={c.id} className="badge bg-primary-light text-primary" style={{ fontSize: '0.7rem' }}>
//                   {c.title}
//                 </span>
//               ))}
//               <span className={`badge-level ${course.level}`}>{course.level}</span>
//               {course.featured && (
//                 <span className="badge bg-warning text-dark" style={{ fontSize: '0.7rem' }}>Featured</span>
//               )}
//             </div>

//             <h1 className="fw-bold mb-2" style={{ fontSize: '1.75rem' }}>{course.title}</h1>
//             {course.short_description && <p className="text-muted mb-3">{course.short_description}</p>}

//             <div className="d-flex align-items-center gap-3 flex-wrap mb-3">
//               {course.avg_rating && (
//                 <div className="d-flex align-items-center gap-1">
//                   <span className="fw-700 text-warning">{course.avg_rating}</span>
//                   <RatingStars rating={course.avg_rating} />
//                 </div>
//               )}
//               <span className="text-muted" style={{ fontSize: '0.8rem' }}>
//                 <i className="bi bi-people me-1" />{course.enrolled_count ?? 0} enrolled
//               </span>
//               <span className="text-muted" style={{ fontSize: '0.8rem' }}>
//                 <i className="bi bi-book me-1" />{course.lessons_count ?? 0} lessons
//               </span>
//               {course.duration_weeks && (
//                 <span className="text-muted" style={{ fontSize: '0.8rem' }}>
//                   <i className="bi bi-clock me-1" />{course.duration_weeks} weeks
//                 </span>
//               )}
//               <span className="text-muted" style={{ fontSize: '0.8rem' }}>
//                 <i className="bi bi-translate me-1" />{course.lang?.toUpperCase()}
//               </span>
//             </div>

//             {course.creator && (
//               <div className="d-flex align-items-center gap-2">
//                 <Avatar image={course.creator.image} name={course.creator.name} size={36} />
//                 <div>
//                   <div className="fw-600" style={{ fontSize: '0.875rem' }}>{course.creator.name}</div>
//                   <div className="text-muted" style={{ fontSize: '0.72rem' }}>Course Creator</div>
//                 </div>
//               </div>
//             )}
//           </div>

//           {/* Assigned instructors */}
//           {course.tutors && course.tutors.length > 0 && (
//             <div className="card mb-4 p-3">
//               <h6 className="fw-700 mb-2">
//                 <i className="bi bi-person-video3 me-2 text-primary" />
//                 Assigned Instructor{course.tutors.length > 1 ? 's' : ''}
//               </h6>
//               <div className="d-flex gap-3 flex-wrap">
//                 {course.tutors.map((t: any) => (
//                   <div key={t.id} className="d-flex align-items-center gap-2">
//                     <Avatar image={t.image} name={t.name} size={36} />
//                     <div>
//                       <div className="fw-600" style={{ fontSize: '0.8rem' }}>{t.name}</div>
//                       <div className="text-muted" style={{ fontSize: '0.7rem' }}>Instructor</div>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}

//           {/* What you'll learn */}
//           {course.what_you_learn && (
//             <div className="card mb-4 p-4">
//               <h5 className="fw-700 mb-3"><i className="bi bi-lightbulb me-2 text-warning" />What You'll Learn</h5>
//               <div className="row g-2">
//                 {course.what_you_learn.split('\n').filter(Boolean).map((item: string, i: number) => (
//                   <div key={i} className="col-sm-6 d-flex align-items-start gap-2">
//                     <i className="bi bi-check-circle-fill text-success mt-1" style={{ flexShrink: 0 }} />
//                     <span style={{ fontSize: '0.875rem' }}>{item}</span>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}

//           {/* Curriculum */}
//           <div className="card mb-4">
//             <div className="card-header-custom">
//               <h5 className="fw-700 mb-0"><i className="bi bi-list-ol me-2 text-primary" />Curriculum</h5>
//               <span className="text-muted" style={{ fontSize: '0.8rem' }}>
//                 {course.lessons_count} lessons · {course.topics_count} topics
//               </span>
//             </div>
//             <div>
//               {(course.lessons || []).map((lesson: any, li: number) => (
//                 <div key={lesson.id}>
//                   <button
//                     className="lesson-header w-100 text-start border-0 bg-transparent"
//                     onClick={() => setOpenLesson(openLesson === li ? null : li)}
//                   >
//                     <span><i className="bi bi-collection me-2 text-primary" />{lesson.title}</span>
//                     <span className="d-flex align-items-center gap-2">
//                       <span className="text-muted" style={{ fontSize: '0.75rem' }}>
//                         {(lesson.topics || []).length} topics
//                       </span>
//                       <i className={`bi ${openLesson === li ? 'bi-chevron-up' : 'bi-chevron-down'} text-muted`} />
//                     </span>
//                   </button>

//                   {openLesson === li && (lesson.topics || []).map((topic: any) => (
//                     <div key={topic.id} className="topic-item">
//                       <i className={`bi ${topic.is_free_preview ? 'bi-play-circle text-primary' : 'bi-lock text-muted'}`} />
//                       <span className="flex-1">{topic.title}</span>
//                       {topic.duration_minutes && (
//                         <span className="text-muted" style={{ fontSize: '0.7rem' }}>{topic.duration_minutes}m</span>
//                       )}
//                       {topic.is_free_preview && (
//                         <span className="badge bg-success-light text-success" style={{ fontSize: '0.65rem' }}>Preview</span>
//                       )}
//                     </div>
//                   ))}
//                 </div>
//               ))}
//             </div>
//           </div>

//           {/* Requirements */}
//           {course.requirements && (
//             <div className="card mb-4 p-4">
//               <h5 className="fw-700 mb-3">Requirements</h5>
//               <ul className="mb-0" style={{ fontSize: '0.875rem', paddingLeft: '1.25rem' }}>
//                 {course.requirements.split('\n').filter(Boolean).map((r: string, i: number) => (
//                   <li key={i}>{r}</li>
//                 ))}
//               </ul>
//             </div>
//           )}
//         </div>

//         {/* ── Sidebar — enroll card ── */}
//         <div className="col-lg-4">
//           <div className="card sticky-top" style={{ top: 'calc(var(--nav-height) + 1rem)' }}>

//             {/* Preview / thumbnail */}
//             {course.preview_video ? (
//               <div className="video-wrapper" style={{ borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0' }}>
//                 <video
//                   controls
//                   poster={thumbSrc}
//                   style={{ borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0' }}
//                 >
//                   <source src={course.preview_video} />
//                 </video>
//               </div>
//             ) : thumbSrc ? (
//               <img
//                 src={thumbSrc}
//                 alt={course.title}
//                 style={{ width: '100%', height: 200, objectFit: 'cover', borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0' }}
//                 onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
//               />
//             ) : (
//               <div style={{
//                 height: 180,
//                 background: 'linear-gradient(135deg, var(--primary-light), #e8f4fd)',
//                 borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0',
//                 display: 'flex', alignItems: 'center', justifyContent: 'center',
//               }}>
//                 <i className="bi bi-play-circle text-primary" style={{ fontSize: '3rem' }} />
//               </div>
//             )}

//             <div className="p-4">
//               {/* Price display */}
//               <div className="mb-3">
//                 {course.fee > 0 ? (
//                   <>
//                     <div className="d-flex align-items-baseline gap-2">
//                       <span className="fw-bold" style={{ fontSize: '1.75rem', color: 'var(--primary)' }}>
//                         ₦{displayPrice.toLocaleString()}
//                       </span>
//                       {discountInfo?.valid && (
//                         <span className="text-muted text-decoration-line-through" style={{ fontSize: '1rem' }}>
//                           ₦{course.fee.toLocaleString()}
//                         </span>
//                       )}
//                     </div>
//                     {discountInfo?.valid && (
//                       <div className="text-success fw-600" style={{ fontSize: '0.8rem' }}>
//                         You save ₦{discountInfo.savings.toLocaleString()}
//                       </div>
//                     )}
//                     <div className="text-muted" style={{ fontSize: '0.75rem' }}>
//                       {course.payment_type === 'one_time'    ? 'One-time payment'              :
//                        course.payment_type === 'subscription' ? `${course.subscription_interval}ly subscription` :
//                        'Pay as you go'}
//                     </div>
//                   </>
//                 ) : (
//                   <span className="badge bg-success" style={{ fontSize: '1rem', padding: '0.5rem 1rem' }}>Free</span>
//                 )}
//               </div>

//               {/* Discount code */}
//               {course.fee > 0 && !course.is_enrolled && (
//                 <div className="mb-3">
//                   <div className="d-flex gap-2">
//                     <input
//                       type="text"
//                       className="form-control form-control-sm"
//                       placeholder="Discount code"
//                       value={discountCode}
//                       onChange={e => setDiscountCode(e.target.value.toUpperCase())}
//                     />
//                     <button
//                       className="btn btn-sm btn-outline-primary"
//                       onClick={checkDiscount}
//                       disabled={checking || !discountCode}
//                     >
//                       {checking ? <span className="spinner-border spinner-border-sm" /> : 'Apply'}
//                     </button>
//                   </div>
//                 </div>
//               )}

//               {/* CTA */}
//               {course.is_enrolled ? (
//                 <Link
//                   to={`/learn/${course.slug}`}
//                   className="btn btn-success w-100 py-2 fw-600 btn-icon-start mb-3"
//                 >
//                   <i className="bi bi-play-fill" /> Continue Learning
//                   {(course.progress_pct ?? 0) > 0 && (
//                     <span className="ms-auto opacity-75">{course.progress_pct}%</span>
//                   )}
//                 </Link>
//               ) : (
//                 <button
//                   className="btn btn-primary w-100 py-2 fw-600 mb-3"
//                   onClick={handleEnroll}
//                   disabled={enrolling}
//                 >
//                   {enrolling
//                     ? <><span className="spinner-border spinner-border-sm me-2" />Processing…</>
//                     : course.fee > 0
//                       ? `Enroll · ₦${displayPrice.toLocaleString()}`
//                       : 'Enroll for Free'}
//                 </button>
//               )}

//               {/* Course includes */}
//               <div className="d-flex flex-column gap-2">
//                 {[
//                   { icon: 'bi-collection',        text: `${course.lessons_count ?? 0} lessons` },
//                   { icon: 'bi-file-earmark-play',  text: `${course.topics_count  ?? 0} topics` },
//                   ...(course.duration_weeks ? [{ icon: 'bi-clock', text: `${course.duration_weeks} weeks` }] : []),
//                   { icon: 'bi-phone',  text: 'Mobile & desktop access' },
//                   { icon: 'bi-award', text: 'Certificate on completion' },
//                 ].map((item, i) => (
//                   <div key={i} className="d-flex align-items-center gap-2 text-muted" style={{ fontSize: '0.8rem' }}>
//                     <i className={`bi ${item.icon} text-primary`} style={{ width: 16 }} />
//                     {item.text}
//                   </div>
//                 ))}
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }




// // v3 — responsive + always-visible enroll CTA
// import { useState, useEffect } from 'react';
// import { useParams, useNavigate, useSearchParams, Link } from 'react-router-dom';
// import toast from 'react-hot-toast';
// import { coursesApi, enrollmentsApi, paymentsApi } from '@/services/api';
// import { Course } from '@/types';
// import { Spinner, RatingStars, Avatar } from '@/components/shared';
// import { useAuth } from '@/context/AuthContext';
// import '@/styles/pages/courses/CourseDetail.css';

// /* ═══════════════════════════════════════════
//    Helpers
//    ═══════════════════════════════════════════ */

// /**
//  * Resolve a backend media path to a fully-qualified URL.
//  * Handles bare filenames, rooted paths, and already-absolute URLs.
//  */
// function mediaUrl(
//   path: string | null | undefined,
//   folder = 'courses/thumbnails',
// ): string | undefined {
//   if (!path) return undefined;
//   if (path.startsWith('http')) return path;
//   const base = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '');
//   if (path.startsWith('/')) return `${base}${path}`;
//   return `${base}/uploads/${folder}/${path}`;
// }

// function paymentLabel(course: Course): string {
//   if (course.payment_type === 'one_time')    return 'One-time payment';
//   if (course.payment_type === 'subscription') return `${course.subscription_interval ?? 'Monthly'}ly subscription`;
//   return 'Pay as you go';
// }

// /* ═══════════════════════════════════════════
//    CourseDetail
//    ═══════════════════════════════════════════ */
// export default function CourseDetail() {
//   const { slug }       = useParams<{ slug: string }>();
//   const [searchParams] = useSearchParams();
//   const { user }       = useAuth();
//   const navigate       = useNavigate();

//   const [course,       setCourse]       = useState<Course | null>(null);
//   const [loading,      setLoading]      = useState(true);
//   const [enrolling,    setEnrolling]    = useState(false);
//   const [openLesson,   setOpenLesson]   = useState<number | null>(0);
//   const [discountCode, setDiscountCode] = useState('');
//   const [discountInfo, setDiscountInfo] = useState<any>(null);
//   const [checking,     setChecking]     = useState(false);

//   /* ── Load course ── */
//   useEffect(() => {
//     if (!slug) return;
//     coursesApi
//       .get(slug)
//       .then(r => setCourse(r.data))
//       .catch(() => navigate('/explore'))
//       .finally(() => setLoading(false));
//   }, [slug]);

//   /* ── Handle Paystack callback ── */
//   useEffect(() => {
//     const reference = searchParams.get('reference') || searchParams.get('trxref');
//     if (!reference || !course) return;

//     paymentsApi
//       .verify(reference)
//       .then(r => {
//         if (r.data?.status === 'success' || r.data?.paid) {
//           toast.success('Payment successful! You are now enrolled.');
//           coursesApi.get(slug!).then(r2 => setCourse(r2.data));
//         } else {
//           toast.error('Payment could not be verified. Contact support if you were charged.');
//         }
//       })
//       .catch(() => toast.error('Payment verification failed'))
//       .finally(() => navigate(`/courses/${slug}`, { replace: true }));
//   }, [course, searchParams]);

//   /* ── Enroll / pay ── */
//   const handleEnroll = async () => {
//     if (!user)   { navigate('/auth/signin'); return; }
//     if (!course) return;

//     setEnrolling(true);
//     try {
//       if (course.fee > 0) {
//         const res = await paymentsApi.initiate({
//           course_id:     course.id,
//           payment_type:  course.payment_type,
//           discount_code: discountCode || undefined,
//           callback_url:  `${window.location.origin}/courses/${course.slug}`,
//         });
//         window.location.href = res.data.payment_url;
//       } else {
//         await enrollmentsApi.enroll(course.id);
//         toast.success('Enrolled successfully!');
//         navigate(`/learn/${course.slug}`);
//       }
//     } catch (err: any) {
//       toast.error(err.response?.data?.detail || 'Enrollment failed');
//     } finally {
//       setEnrolling(false);
//     }
//   };

//   /* ── Discount code ── */
//   const checkDiscount = async () => {
//     if (!discountCode || !course) return;
//     setChecking(true);
//     try {
//       const res = await paymentsApi.validateDiscount({
//         code: discountCode, course_id: course.id,
//       });
//       setDiscountInfo(res.data);
//       res.data.valid ? toast.success(res.data.message) : toast.error(res.data.message);
//     } catch {
//       toast.error('Could not validate code');
//     } finally {
//       setChecking(false);
//     }
//   };

//   /* ── Guards ── */
//   if (loading) return <Spinner />;
//   if (!course) return null;

//   const displayPrice = discountInfo?.valid ? discountInfo.final_price : course.fee;
//   const thumbSrc     = mediaUrl(course.thumbnail);
//   const isFree       = course.fee === 0;
//   const isEnrolled   = course.is_enrolled;
//   const progress     = course.progress_pct ?? 0;

//   /* ── Reusable CTA button logic (same in sidebar + sticky bar) ── */
//   const ctaLabel = enrolling
//     ? 'Processing…'
//     : isEnrolled
//       ? `Continue Learning${progress > 0 ? ` · ${progress}%` : ''}`
//       : isFree
//         ? 'Enroll for Free'
//         : `Enroll · ₦${displayPrice.toLocaleString()}`;

//   /* ── What-you'll-learn items ── */
//   const learnItems = (course.what_you_learn || '')
//     .split('\n')
//     .map(s => s.trim())
//     .filter(Boolean);

//   /* ── Requirements ── */
//   const requirements = (course.requirements || '')
//     .split('\n')
//     .map(s => s.trim())
//     .filter(Boolean);

//   /* ── Course-includes list ── */
//   const includes = [
//     { icon: 'bi-collection',       label: `${course.lessons_count ?? 0} lessons` },
//     { icon: 'bi-file-earmark-play', label: `${course.topics_count ?? 0} topics` },
//     ...(course.duration_weeks
//       ? [{ icon: 'bi-clock', label: `${course.duration_weeks} weeks` }]
//       : []),
//     { icon: 'bi-phone',  label: 'Mobile & desktop access' },
//     { icon: 'bi-award',  label: 'Certificate on completion' },
//   ];

//   /* ═══════════════════════════════════════════
//      Sub-components
//      ═══════════════════════════════════════════ */

//   /** Thumbnail / preview video block */
//   const Thumbnail = () => {
//     if (course.preview_video) {
//       return (
//         <div className="cd-preview-video-wrap">
//           <video controls poster={thumbSrc}>
//             <source src={course.preview_video} />
//           </video>
//         </div>
//       );
//     }
//     if (thumbSrc) {
//       return (
//         <img
//           src={thumbSrc}
//           alt={course.title}
//           className="cd-thumb"
//           onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
//         />
//       );
//     }
//     return (
//       <div className="cd-thumb-placeholder">
//         <i className="bi bi-play-circle" />
//       </div>
//     );
//   };

//   /** Price block — used in both sidebar and sticky bar */
//   const PriceBlock = ({ compact = false }: { compact?: boolean }) => {
//     if (isFree) {
//       return compact
//         ? <span className="cd-sticky-cta-price-main" style={{ color: 'var(--success, #16a34a)' }}>Free</span>
//         : <span className="cd-free-badge">Free</span>;
//     }
//     return (
//       <>
//         {compact ? (
//           <div className="cd-sticky-cta-price">
//             <span className="cd-sticky-cta-price-main">
//               ₦{displayPrice.toLocaleString()}
//             </span>
//             {discountInfo?.valid && (
//               <span className="cd-sticky-cta-price-orig">
//                 ₦{course.fee.toLocaleString()}
//               </span>
//             )}
//           </div>
//         ) : (
//           <div className="cd-price-row">
//             <div>
//               <span className="cd-price-main">₦{displayPrice.toLocaleString()}</span>
//               {discountInfo?.valid && (
//                 <span className="cd-price-original">₦{course.fee.toLocaleString()}</span>
//               )}
//             </div>
//             {discountInfo?.valid && (
//               <div className="cd-price-savings">
//                 You save ₦{discountInfo.savings.toLocaleString()}
//               </div>
//             )}
//             <div className="cd-price-type">{paymentLabel(course)}</div>
//           </div>
//         )}
//       </>
//     );
//   };

//   /** Primary CTA button / link */
//   const CtaButton = ({
//     className = '',
//     fullWidth = false,
//   }: {
//     className?: string;
//     fullWidth?: boolean;
//   }) => {
//     const base = `btn fw-700${fullWidth ? ' w-100' : ''}${className ? ` ${className}` : ''}`;
//     if (isEnrolled) {
//       return (
//         <Link
//           to={`/learn/${course.slug}`}
//           className={`${base} btn-success py-2`}
//         >
//           <i className="bi bi-play-fill me-1" />
//           Continue Learning
//           {progress > 0 && (
//             <span className="ms-auto opacity-75">{progress}%</span>
//           )}
//         </Link>
//       );
//     }
//     return (
//       <button
//         className={`${base} btn-primary py-2`}
//         onClick={handleEnroll}
//         disabled={enrolling}
//       >
//         {enrolling ? (
//           <><span className="spinner-border spinner-border-sm me-2" />Processing…</>
//         ) : ctaLabel}
//       </button>
//     );
//   };

//   /* ═══════════════════════════════════════════
//      Render
//      ═══════════════════════════════════════════ */
//   return (
//     <div className="cd-page-root fade-in">

//       {/* Breadcrumb */}
//       <nav className="cd-breadcrumb" aria-label="Breadcrumb">
//         <ol className="breadcrumb">
//           <li className="breadcrumb-item"><Link to="/">Home</Link></li>
//           <li className="breadcrumb-item"><Link to="/explore">Courses</Link></li>
//           <li className="breadcrumb-item active" aria-current="page">{course.title}</li>
//         </ol>
//       </nav>

//       <div className="row g-4">

//         {/* ────────────── Main column ────────────── */}
//         <div className="col-lg-8">

//           {/* ── Course hero ── */}
//           <div className="cd-header">
//             {/* Badges */}
//             <div className="cd-badges">
//               {(course.categories || []).map((c: any) => (
//                 <span key={c.id} className="cd-cat-badge">{c.title}</span>
//               ))}
//               {course.level && (
//                 <span className={`badge-level ${course.level}`}>{course.level}</span>
//               )}
//               {course.featured && (
//                 <span className="cd-badge-featured">Featured</span>
//               )}
//             </div>

//             <h1 className="cd-title">{course.title}</h1>
//             {course.short_description && (
//               <p className="cd-short-desc">{course.short_description}</p>
//             )}

//             {/* Meta row */}
//             <div className="cd-meta">
//               {course.avg_rating != null && (
//                 <div className="cd-meta-item">
//                   <span className="cd-rating-val">{course.avg_rating}</span>
//                   <RatingStars rating={course.avg_rating} />
//                 </div>
//               )}
//               <span className="cd-meta-item">
//                 <i className="bi bi-people" />{course.enrolled_count ?? 0} enrolled
//               </span>
//               <span className="cd-meta-item">
//                 <i className="bi bi-book" />{course.lessons_count ?? 0} lessons
//               </span>
//               {course.duration_weeks && (
//                 <span className="cd-meta-item">
//                   <i className="bi bi-clock" />{course.duration_weeks} weeks
//                 </span>
//               )}
//               {course.lang && (
//                 <span className="cd-meta-item">
//                   <i className="bi bi-translate" />{course.lang.toUpperCase()}
//                 </span>
//               )}
//             </div>

//             {/* Creator */}
//             {course.creator && (
//               <div className="cd-creator">
//                 <Avatar image={course.creator.image} name={course.creator.name} size={36} />
//                 <div>
//                   <div className="cd-creator-name">{course.creator.name}</div>
//                   <div className="cd-creator-role">Course Creator</div>
//                 </div>
//               </div>
//             )}
//           </div>

//           {/* ── Assigned instructors ── */}
//           {course.tutors && course.tutors.length > 0 && (
//             <div className="cd-instructors-card">
//               <div className="cd-instructors-title">
//                 <i className="bi bi-person-video3 text-primary" />
//                 Assigned Instructor{course.tutors.length > 1 ? 's' : ''}
//               </div>
//               <div className="cd-instructors-list">
//                 {course.tutors.map((t: any) => (
//                   <div key={t.id} className="cd-instructor-item">
//                     <Avatar image={t.image} name={t.name} size={36} />
//                     <div>
//                       <div className="cd-instructor-name">{t.name}</div>
//                       <div className="cd-instructor-role">Instructor</div>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}

//           {/* ── What you'll learn ── */}
//           {learnItems.length > 0 && (
//             <div className="cd-learn-card">
//               <h5>
//                 <i className="bi bi-lightbulb text-warning" />
//                 What You'll Learn
//               </h5>
//               <div className="cd-learn-grid">
//                 {learnItems.map((item, i) => (
//                   <div key={i} className="cd-learn-item">
//                     <i className="bi bi-check-circle-fill" />
//                     <span>{item}</span>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}

//           {/* ── Curriculum ── */}
//           <div className="cd-curriculum-card">
//             <div className="cd-curriculum-header">
//               <h5>
//                 <i className="bi bi-list-ol text-primary" />
//                 Curriculum
//               </h5>
//               <span className="cd-count">
//                 {course.lessons_count} lessons · {course.topics_count} topics
//               </span>
//             </div>

//             <div>
//               {(course.lessons || []).map((lesson: any, li: number) => (
//                 <div key={lesson.id}>
//                   <button
//                     className="cd-lesson-btn"
//                     onClick={() => setOpenLesson(openLesson === li ? null : li)}
//                     aria-expanded={openLesson === li}
//                   >
//                     <span className="cd-lesson-btn-left">
//                       <i className="bi bi-collection text-primary" />
//                       {lesson.title}
//                     </span>
//                     <span className="cd-lesson-btn-right">
//                       <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
//                         {(lesson.topics || []).length} topics
//                       </span>
//                       <i
//                         className={`bi ${openLesson === li ? 'bi-chevron-up' : 'bi-chevron-down'}`}
//                         style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}
//                       />
//                     </span>
//                   </button>

//                   {openLesson === li && (lesson.topics || []).map((topic: any) => (
//                     <div key={topic.id} className="cd-topic-row">
//                       <i
//                         className={`bi ${topic.is_free_preview ? 'bi-play-circle text-primary' : 'bi-lock'}`}
//                         style={{ fontSize: '0.85rem', color: topic.is_free_preview ? undefined : 'var(--text-muted)', flexShrink: 0 }}
//                       />
//                       <span className="cd-topic-title">{topic.title}</span>
//                       {topic.duration_minutes && (
//                         <span className="cd-topic-duration">{topic.duration_minutes}m</span>
//                       )}
//                       {topic.is_free_preview && (
//                         <span className="cd-preview-badge">Preview</span>
//                       )}
//                     </div>
//                   ))}
//                 </div>
//               ))}
//             </div>
//           </div>

//           {/* ── Requirements ── */}
//           {requirements.length > 0 && (
//             <div className="cd-req-card">
//               <h5>Requirements</h5>
//               <ul className="cd-req-list">
//                 {requirements.map((r, i) => <li key={i}>{r}</li>)}
//               </ul>
//             </div>
//           )}

//         </div>
//         {/* ── end col-lg-8 ── */}

//         {/* ────────────── Sidebar column ────────────── */}
//         <div className="col-lg-4">
//           <div className="cd-enroll-card">

//             {/* Thumbnail / preview video */}
//             <Thumbnail />

//             <div className="cd-enroll-body">

//               {/* Price */}
//               <PriceBlock compact={false} />

//               {/* Discount code — only for paid, un-enrolled courses */}
//               {!isFree && !isEnrolled && (
//                 <div className="mb-3">
//                   <div className="d-flex gap-2">
//                     <input
//                       type="text"
//                       className="form-control form-control-sm"
//                       placeholder="Discount code"
//                       value={discountCode}
//                       onChange={e => setDiscountCode(e.target.value.toUpperCase())}
//                       onKeyDown={e => e.key === 'Enter' && checkDiscount()}
//                     />
//                     <button
//                       className="btn btn-sm btn-outline-primary"
//                       onClick={checkDiscount}
//                       disabled={checking || !discountCode}
//                       style={{ whiteSpace: 'nowrap' }}
//                     >
//                       {checking
//                         ? <span className="spinner-border spinner-border-sm" />
//                         : 'Apply'}
//                     </button>
//                   </div>
//                 </div>
//               )}

//               {/* Primary CTA */}
//               <div className="mb-3">
//                 <CtaButton fullWidth />
//               </div>

//               {/* Course includes */}
//               <div className="cd-includes">
//                 {includes.map((item, i) => (
//                   <div key={i} className="cd-include-item">
//                     <i className={`bi ${item.icon}`} />
//                     {item.label}
//                   </div>
//                 ))}
//               </div>

//             </div>
//           </div>
//         </div>
//         {/* ── end col-lg-4 ── */}

//       </div>

//       {/* ══════════════════════════════════════════════
//           Mobile sticky CTA bar
//           Always visible on screens < 992px.
//           Hidden on desktop (the sidebar card handles it).
//           ═══════════════════════════════════════════ */}
//       <div className="cd-sticky-cta" role="region" aria-label="Quick enroll">

//         {/* Price summary */}
//         {isEnrolled ? (
//           <div className="cd-sticky-cta-price">
//             <span
//               className="cd-sticky-cta-price-main"
//               style={{ color: 'var(--success, #16a34a)', fontSize: '0.85rem' }}
//             >
//               Enrolled{progress > 0 ? ` · ${progress}%` : ''}
//             </span>
//           </div>
//         ) : (
//           <PriceBlock compact />
//         )}

//         {/* CTA button */}
//         {isEnrolled ? (
//           <Link
//             to={`/learn/${course.slug}`}
//             className="cd-sticky-cta-btn enrolled"
//           >
//             <i className="bi bi-play-fill" />
//             Continue Learning
//           </Link>
//         ) : (
//           <button
//             className="cd-sticky-cta-btn enroll"
//             onClick={handleEnroll}
//             disabled={enrolling}
//           >
//             {enrolling ? (
//               <><span className="spinner-border spinner-border-sm" style={{ width: 14, height: 14 }} />Processing…</>
//             ) : isFree ? (
//               <><i className="bi bi-lightning-fill" />Enroll for Free</>
//             ) : (
//               <><i className="bi bi-lock-fill" />Enroll · ₦{displayPrice.toLocaleString()}</>
//             )}
//           </button>
//         )}

//       </div>

//     </div>
//   );
// }



// v3
// v3 — price + CTA side-by-side, branded default preview,
//       enroll disabled for courses with no content
import { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { coursesApi, enrollmentsApi, paymentsApi } from '@/services/api';
import { Course } from '@/types';
import { Spinner, RatingStars, Avatar } from '@/components/shared';
import { useAuth } from '@/context/AuthContext';
import '@/styles/pages/courses/CourseDetail.css';

/* ═══════════════════════════════════════════
   Helpers
   ═══════════════════════════════════════════ */

/**
 * Resolve a backend media path to a fully-qualified URL.
 * Handles bare filenames, rooted paths, and absolute URLs.
 */
function mediaUrl(
  path: string | null | undefined,
  folder = 'courses/thumbnails',
): string | undefined {
  if (!path) return undefined;
  if (path.startsWith('http')) return path;
  const base = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '');
  if (path.startsWith('/')) return `${base}${path}`;
  return `${base}/uploads/${folder}/${path}`;
}

function paymentTypeLabel(course: Course): string {
  if (course.payment_type === 'one_time')     return 'One-time payment';
  if (course.payment_type === 'subscription') return `${course.subscription_interval ?? 'Monthly'}ly subscription`;
  return 'Pay as you go';
}

/** A course is considered "ready" if it has at least one topic with content. */
function courseIsReady(course: Course): boolean {
  return (course.topics_count ?? 0) > 0;
}

/* ═══════════════════════════════════════════
   Component
   ═══════════════════════════════════════════ */
export default function CourseDetail() {
  const { slug }       = useParams<{ slug: string }>();
  const [searchParams] = useSearchParams();
  const { user }       = useAuth();
  const navigate       = useNavigate();

  const [course,       setCourse]       = useState<Course | null>(null);
  const [loading,      setLoading]      = useState(true);
  const [enrolling,    setEnrolling]    = useState(false);
  const [openLesson,   setOpenLesson]   = useState<number | null>(0);
  const [discountCode, setDiscountCode] = useState('');
  const [discountInfo, setDiscountInfo] = useState<any>(null);
  const [checking,     setChecking]     = useState(false);

  /* ── Load course ── */
  useEffect(() => {
    if (!slug) return;
    coursesApi
      .get(slug)
      .then(r => setCourse(r.data))
      .catch(() => navigate('/explore'))
      .finally(() => setLoading(false));
  }, [slug]);

  /* ── Handle Paystack callback ── */
  useEffect(() => {
    const reference = searchParams.get('reference') || searchParams.get('trxref');
    if (!reference || !course) return;

    paymentsApi
      .verify(reference)
      .then(r => {
        if (r.data?.status === 'success' || r.data?.paid) {
          toast.success('Payment successful! You are now enrolled.');
          coursesApi.get(slug!).then(r2 => setCourse(r2.data));
        } else {
          toast.error('Payment could not be verified. Contact support if you were charged.');
        }
      })
      .catch(() => toast.error('Payment verification failed'))
      .finally(() => navigate(`/courses/${slug}`, { replace: true }));
  }, [course, searchParams]);

  /* ── Enroll / pay ── */
  const handleEnroll = async () => {
    if (!user)   { navigate('/auth/signin'); return; }
    if (!course) return;

    setEnrolling(true);
    try {
      if (course.fee > 0) {
        const res = await paymentsApi.initiate({
          course_id:     course.id,
          payment_type:  course.payment_type,
          discount_code: discountCode || undefined,
          callback_url:  `${window.location.origin}/courses/${course.slug}`,
        });
        window.location.href = res.data.payment_url;
      } else {
        await enrollmentsApi.enroll(course.id);
        toast.success('Enrolled successfully!');
        navigate(`/learn/${course.slug}`);
      }
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Enrollment failed');
    } finally {
      setEnrolling(false);
    }
  };

  /* ── Discount code ── */
  const checkDiscount = async () => {
    if (!discountCode || !course) return;
    setChecking(true);
    try {
      const res = await paymentsApi.validateDiscount({ code: discountCode, course_id: course.id });
      setDiscountInfo(res.data);
      res.data.valid ? toast.success(res.data.message) : toast.error(res.data.message);
    } catch {
      toast.error('Could not validate code');
    } finally {
      setChecking(false);
    }
  };

  /* ── Guards ── */
  if (loading) return <Spinner />;
  if (!course) return null;

  const displayPrice = discountInfo?.valid ? discountInfo.final_price : course.fee;
  const thumbSrc     = mediaUrl(course.thumbnail);
  const isFree       = course.fee === 0;
  const isEnrolled   = !!course.is_enrolled;
  const isReady      = courseIsReady(course);
  const progress     = course.progress_pct ?? 0;

  const learnItems   = (course.what_you_learn ?? '').split('\n').map(s => s.trim()).filter(Boolean);
  const requirements = (course.requirements   ?? '').split('\n').map(s => s.trim()).filter(Boolean);

  const includes = [
    { icon: 'bi-collection',       label: `${course.lessons_count ?? 0} lessons` },
    { icon: 'bi-file-earmark-play', label: `${course.topics_count ?? 0} topics` },
    ...(course.duration_weeks ? [{ icon: 'bi-clock', label: `${course.duration_weeks} weeks` }] : []),
    { icon: 'bi-phone',  label: 'Mobile & desktop access' },
    { icon: 'bi-award',  label: 'Certificate on completion' },
  ];

  /* ─── Sub-components ─── */

  /** Branded default placeholder — shown when no thumbnail and no preview video */
  const Thumbnail = () => {
    if (course.preview_video) {
      return (
        <div className="cd-preview-video-wrap">
          <video controls poster={thumbSrc ?? undefined}>
            <source src={course.preview_video} />
          </video>
        </div>
      );
    }
    if (thumbSrc) {
      return (
        <img
          src={thumbSrc}
          alt={course.title}
          className="cd-thumb"
          onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
        />
      );
    }
    /* Default branded placeholder */
    return (
      <div className="cd-thumb-placeholder" aria-hidden="true">
        <i className="bi bi-play-circle cd-thumb-placeholder-icon" />
        <span className="cd-thumb-placeholder-label">Course Preview</span>
      </div>
    );
  };

  /** Price block — used in sidebar card and sticky bar */
  const PriceBlock = ({ compact = false }: { compact?: boolean }) => {
    if (isFree) {
      return compact
        ? <div className="cd-sticky-price"><span className="cd-sticky-price-main" style={{ color: 'var(--success, #16a34a)' }}>Free</span></div>
        : <div className="cd-price-block"><span className="cd-free-badge"><i className="bi bi-lightning-fill me-1" />Free</span></div>;
    }
    if (compact) {
      return (
        <div className="cd-sticky-price">
          <span className="cd-sticky-price-main">₦{displayPrice.toLocaleString()}</span>
          {discountInfo?.valid && (
            <span className="cd-sticky-price-orig">₦{course.fee.toLocaleString()}</span>
          )}
        </div>
      );
    }
    return (
      <div className="cd-price-block">
        <span className="cd-price-main">
          ₦{displayPrice.toLocaleString()}
          {discountInfo?.valid && (
            <span className="cd-price-original">₦{course.fee.toLocaleString()}</span>
          )}
        </span>
        {discountInfo?.valid && (
          <div className="cd-price-savings">You save ₦{discountInfo.savings.toLocaleString()}</div>
        )}
        <div className="cd-price-type">{paymentTypeLabel(course)}</div>
      </div>
    );
  };

  /**
   * Primary CTA button/link.
   * variant: 'card' (sidebar) | 'sticky' (bottom bar)
   */
  const CtaButton = ({ variant = 'card' }: { variant?: 'card' | 'sticky' }) => {
    const cls      = variant === 'sticky' ? 'cd-sticky-btn' : 'cd-cta-btn';
    const spinning = <><span className="spinner-border spinner-border-sm" style={{ width: 14, height: 14 }} /> Processing…</>;

    /* Enrolled → go to learning */
    if (isEnrolled) {
      return (
        <Link to={`/learn/${course.slug}`} className={`${cls} success`}>
          <i className="bi bi-play-fill" />
          Continue Learning
          {progress > 0 && <span className="ms-1 opacity-75" style={{ fontSize: '0.8em' }}>{progress}%</span>}
        </Link>
      );
    }

    /* Course not ready → disabled CTA */
    if (!isReady) {
      return (
        <button className={`${cls} ${variant === 'sticky' ? 'disabled-state' : 'disabled'}`} disabled>
          <i className="bi bi-hourglass-split" />
          Coming Soon
        </button>
      );
    }

    return (
      <button
        className={`${cls} primary btn-primary`}
        onClick={handleEnroll}
        disabled={enrolling}
      >
        {enrolling ? spinning : (
          <>
            <i className={`bi ${isFree ? 'bi-lightning-fill' : 'bi-lock-fill'}`} />
            {isFree ? 'Enroll for Free' : `Enroll · ₦${displayPrice.toLocaleString()}`}
          </>
        )}
      </button>
    );
  };

  /* ═══════════════════════════════════════════
     Render
     ═══════════════════════════════════════════ */
  return (
    <div className="cd-root fade-in">

      {/* Breadcrumb */}
      <nav className="cd-breadcrumb" aria-label="Breadcrumb">
        <ol className="breadcrumb">
          <li className="breadcrumb-item"><Link to="/">Home</Link></li>
          <li className="breadcrumb-item"><Link to="/explore">Courses</Link></li>
          <li className="breadcrumb-item active" aria-current="page">{course.title}</li>
        </ol>
      </nav>

      <div className="row g-4">

        {/* ═══════════ Main column ═══════════ */}
        <div className="col-lg-8">

          {/* Hero */}
          <div className="cd-header">
            <div className="cd-badges">
              {(course.categories || []).map((c: any) => (
                <span key={c.id} className="cd-cat-badge">{c.title}</span>
              ))}
              {course.level && (
                <span className={`badge-level ${course.level}`}>{course.level}</span>
              )}
              {course.featured && <span className="cd-badge-featured">Featured</span>}
            </div>

            <h1 className="cd-title">{course.title}</h1>
            {course.short_description && (
              <p className="cd-short-desc">{course.short_description}</p>
            )}

            <div className="cd-meta">
              {course.avg_rating != null && (
                <div className="cd-meta-item">
                  <span className="cd-rating-val">{course.avg_rating}</span>
                  <RatingStars rating={course.avg_rating} />
                </div>
              )}
              <span className="cd-meta-item">
                <i className="bi bi-people" />{course.enrolled_count ?? 0} enrolled
              </span>
              <span className="cd-meta-item">
                <i className="bi bi-book" />{course.lessons_count ?? 0} lessons
              </span>
              {course.duration_weeks && (
                <span className="cd-meta-item">
                  <i className="bi bi-clock" />{course.duration_weeks} weeks
                </span>
              )}
              {course.lang && (
                <span className="cd-meta-item">
                  <i className="bi bi-translate" />{course.lang.toUpperCase()}
                </span>
              )}
            </div>

            {course.creator && (
              <div className="cd-creator">
                <Avatar image={course.creator.image} name={course.creator.name} size={36} />
                <div>
                  <div className="cd-creator-name">{course.creator.name}</div>
                  <div className="cd-creator-role">Course Creator</div>
                </div>
              </div>
            )}
          </div>

          {/* Instructors */}
          {course.tutors && course.tutors.length > 0 && (
            <div className="cd-section-card cd-card-pad">
              <h6>
                <i className="bi bi-person-video3 text-primary" />
                Assigned Instructor{course.tutors.length > 1 ? 's' : ''}
              </h6>
              <div className="cd-instructors-list">
                {course.tutors.map((t: any) => (
                  <div key={t.id} className="cd-instructor-item">
                    <Avatar image={t.image} name={t.name} size={36} />
                    <div>
                      <div className="cd-instructor-name">{t.name}</div>
                      <div className="cd-instructor-role">Instructor</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* What you'll learn */}
          {learnItems.length > 0 && (
            <div className="cd-section-card cd-card-pad">
              <h5><i className="bi bi-lightbulb text-warning" />What You'll Learn</h5>
              <div className="cd-learn-grid">
                {learnItems.map((item, i) => (
                  <div key={i} className="cd-learn-item">
                    <i className="bi bi-check-circle-fill" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Curriculum */}
          <div className="cd-section-card cd-curriculum-card">
            <div className="cd-curriculum-header">
              <h5 className="mb-0">
                <i className="bi bi-list-ol text-primary" />
                Curriculum
              </h5>
              <span className="cd-count">
                {course.lessons_count ?? 0} lessons · {course.topics_count ?? 0} topics
              </span>
            </div>

            {(course.lessons || []).length === 0 ? (
              <div style={{ padding: '1.5rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                <i className="bi bi-inbox d-block mb-2" style={{ fontSize: '1.5rem' }} />
                Curriculum hasn't been added yet.
              </div>
            ) : (
              (course.lessons || []).map((lesson: any, li: number) => (
                <div key={lesson.id}>
                  <button
                    className="cd-lesson-btn"
                    onClick={() => setOpenLesson(openLesson === li ? null : li)}
                    aria-expanded={openLesson === li}
                  >
                    <span className="cd-lesson-btn-left">
                      <i className="bi bi-collection text-primary" />
                      {lesson.title}
                    </span>
                    <span className="cd-lesson-btn-right">
                      {(lesson.topics || []).length} topics
                      <i className={`bi ${openLesson === li ? 'bi-chevron-up' : 'bi-chevron-down'}`} />
                    </span>
                  </button>

                  {openLesson === li && (lesson.topics || []).map((topic: any) => (
                    <div key={topic.id} className="cd-topic-row">
                      <i
                        className={`bi ${topic.is_free_preview ? 'bi-play-circle' : 'bi-lock'}`}
                        style={{ color: topic.is_free_preview ? 'var(--primary)' : 'var(--text-muted)', flexShrink: 0 }}
                      />
                      <span className="cd-topic-title">{topic.title}</span>
                      {topic.duration_minutes && (
                        <span className="cd-topic-duration">{topic.duration_minutes}m</span>
                      )}
                      {topic.is_free_preview && (
                        <span className="cd-preview-badge">Preview</span>
                      )}
                    </div>
                  ))}
                </div>
              ))
            )}
          </div>

          {/* Requirements */}
          {requirements.length > 0 && (
            <div className="cd-section-card cd-card-pad">
              <h5>Requirements</h5>
              <ul className="cd-req-list">
                {requirements.map((r, i) => <li key={i}>{r}</li>)}
              </ul>
            </div>
          )}

        </div>
        {/* ── end col-lg-8 ── */}

        {/* ═══════════ Sidebar column ═══════════ */}
        <div className="col-lg-4">
          <div className="cd-enroll-card">

            <Thumbnail />

            <div className="cd-enroll-body">

              {/* ── Price + CTA side by side ── */}
              <div className="cd-price-cta-row">
                <PriceBlock compact={false} />
                <CtaButton variant="card" />
              </div>

              {/* Not-ready notice */}
              {!isReady && !isEnrolled && (
                <div className="cd-not-ready-notice">
                  <i className="bi bi-hourglass-split" />
                  <div className="cd-not-ready-notice-text">
                    <strong>Content coming soon</strong>
                    The instructor is still preparing this course.
                    Check back shortly — it will be available soon!
                  </div>
                </div>
              )}

              {/* Discount code */}
              {!isFree && !isEnrolled && isReady && (
                <div className="cd-discount-row">
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    placeholder="Discount code"
                    value={discountCode}
                    onChange={e => setDiscountCode(e.target.value.toUpperCase())}
                    onKeyDown={e => e.key === 'Enter' && checkDiscount()}
                  />
                  <button
                    className="btn btn-sm btn-outline-primary"
                    onClick={checkDiscount}
                    disabled={checking || !discountCode}
                    style={{ whiteSpace: 'nowrap' }}
                  >
                    {checking
                      ? <span className="spinner-border spinner-border-sm" />
                      : 'Apply'}
                  </button>
                </div>
              )}

              {/* Course includes */}
              <div className="cd-includes">
                {includes.map((item, i) => (
                  <div key={i} className="cd-include-item">
                    <i className={`bi ${item.icon}`} />
                    {item.label}
                  </div>
                ))}
              </div>

            </div>
          </div>
        </div>
        {/* ── end col-lg-4 ── */}

      </div>

      {/* ═══════════════════════════════════════════
          Mobile sticky CTA bar — always visible on < lg
          ═══════════════════════════════════════════ */}
      <div className="cd-sticky-cta" role="region" aria-label="Quick enroll">
        {isEnrolled ? (
          <div className="cd-sticky-price">
            <span className="cd-sticky-price-main" style={{ color: 'var(--success, #16a34a)', fontSize: '0.8rem' }}>
              Enrolled{progress > 0 ? ` · ${progress}%` : ''}
            </span>
          </div>
        ) : (
          <PriceBlock compact />
        )}

        <CtaButton variant="sticky" />
      </div>

    </div>
  );
}
