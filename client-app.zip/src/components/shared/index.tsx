/// <reference types="vite/client" />
import { Course, Certificate } from '@/types';
import { Link } from 'react-router-dom';
import { useState, useMemo } from 'react';

const API_BASE = import.meta.env.VITE_API_URL?.replace('/api/v1', '') || ''

// ── SPINNER ─────────────────────────────────────
export function Spinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const s = size === 'sm' ? 20 : size === 'lg' ? 48 : 32;
  return (
    <div className="d-flex justify-content-center align-items-center py-4">
      <div className="spinner-border text-primary" style={{ width: s, height: s }} role="status">
        <span className="visually-hidden">Loading…</span>
      </div>
    </div>
  );
}

// ── EMPTY STATE ──────────────────────────────────
export function Empty({ icon = 'bi-inbox', title = 'Nothing here yet', subtitle = '', action }: {
  icon?: string; title?: string; subtitle?: string;
  action?: { label: string; onClick: () => void; href?: string };
}) {
  return (
    <div className="text-center py-5">
      <i className={`bi ${icon} text-muted`} style={{ fontSize: '3rem' }} />
      <h6 className="mt-3 mb-1">{title}</h6>
      {subtitle && <p className="text-muted" style={{ fontSize: '0.875rem' }}>{subtitle}</p>}
      {action && (
        action.href
          ? <Link to={action.href} className="btn btn-primary btn-sm mt-2">{action.label}</Link>
          : <button className="btn btn-primary btn-sm mt-2" onClick={action.onClick}>{action.label}</button>
      )}
    </div>
  );
}

// ── STAT CARD ────────────────────────────────────
export function StatCard({ icon, label, value, color = 'blue', suffix = '', trend }: {
  icon: string; label: string; value: string | number;
  color?: 'blue' | 'green' | 'yellow' | 'purple' | 'red' | 'teal';
  suffix?: string; trend?: number;
}) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${color}`}>
        <i className={`bi ${icon}`} />
      </div>
      <div>
        <div className="stat-value">{typeof value === 'number' ? value.toLocaleString() : value}{suffix}</div>
        <div className="stat-label">{label}</div>
        {trend !== undefined && (
          <div className={`d-flex align-items-center gap-1 mt-1`} style={{ fontSize: '0.75rem', color: trend >= 0 ? 'var(--success)' : 'var(--danger)' }}>
            <i className={`bi bi-arrow-${trend >= 0 ? 'up' : 'down'}-short`} />
            {Math.abs(trend)}% this month
          </div>
        )}
      </div>
    </div>
  );
}

// ── COURSE CARD ──────────────────────────────────
export function CourseCard2({ course, onEnroll }: { course: Course; onEnroll?: (id: number) => void }) {
  const thumbSrc = course.thumbnail
    ? `/uploads/courses/thumbnails/${course.thumbnail}`
    : null;

  return (
    <div className="course-card">
      <Link to={`/courses/${course.slug || course.id}`} style={{ textDecoration: 'none' }}>
        {thumbSrc
          ? <img src={thumbSrc} alt={course.title} className="course-card-img" />
          : <div className="course-card-img-placeholder"><i className="bi bi-play-circle" /></div>
        }
      </Link>
      <div className="course-card-body">
        <div className="d-flex align-items-center gap-2 mb-2">
          <span className={`badge-level ${course.level}`}>{course.level}</span>
          {course.featured && <span className="badge bg-warning text-dark" style={{ fontSize: '0.6rem' }}>Featured</span>}
        </div>
        <Link to={`/courses/${course.slug || course.id}`} className="text-decoration-none">
          <h6 className="course-card-title truncate-2">{course.title}</h6>
        </Link>
        {course.short_description && (
          <p className="text-muted truncate-2" style={{ fontSize: '0.78rem', marginBottom: '0.5rem' }}>{course.short_description}</p>
        )}
        {course.creator && (
          <div className="d-flex align-items-center gap-2 mb-2">
            <img
              src={course.creator.image ? `/uploads/avatars/${course.creator.image}` : `https://ui-avatars.com/api/?name=${encodeURIComponent(course.creator.name || 'I')}&size=24&background=4A90D9&color=fff`}
              alt="" style={{ width: 20, height: 20, borderRadius: '50%', objectFit: 'cover' }}
            />
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{course.creator.name}</span>
          </div>
        )}
        <div className="course-card-meta">
          <span><i className="bi bi-book me-1" />{course.lessons_count} lessons</span>
          <span><i className="bi bi-people me-1" />{course.enrolled_count}</span>
          {course.avg_rating && <span><i className="bi bi-star-fill me-1 text-warning" />{course.avg_rating}</span>}
        </div>
        {course.is_enrolled && (
          <div className="mt-auto">
            <div className="d-flex justify-content-between mb-1" style={{ fontSize: '0.75rem' }}>
              <span className="text-muted">Progress</span>
              <span className="text-primary fw-600">{course.progress_pct}%</span>
            </div>
            <div className="progress"><div className="progress-bar" style={{ width: `${course.progress_pct}%` }} /></div>
          </div>
        )}
      </div>
      <div className="course-card-footer">
        <div>
          {course.fee > 0
            ? <span className="fw-700 text-primary">₦{course.fee.toLocaleString()}</span>
            : <span className="badge bg-success text-white" style={{ fontSize: '0.75rem' }}>Free</span>
          }
        </div>
        {course.is_enrolled
          ? <Link to={`/learn/${course.slug}`} className="btn btn-sm btn-primary btn-icon-start" style={{ borderRadius: 999 }}>
              <i className="bi bi-play-fill" /> Continue
            </Link>
          : <Link to={`/courses/${course.slug || course.id}`} className="btn btn-sm btn-outline-primary" style={{ borderRadius: 999 }}>
              View
            </Link>
        }
      </div>
    </div>
  );
}

// ── COURSE CARD ──────────────────────────────────
export function CourseCard({
  course,
  onEnroll,
}: {
  course: Course;
  onEnroll?: (id: number) => void;
}) {
  // ── Thumbnail handling ─────────────────────────
  const initialThumb = course.thumbnail
    ? `${API_BASE}/uploads/courses/thumbnails/${course.thumbnail}`
    : null;

  const [thumbSrc, setThumbSrc] = useState<string | null>(initialThumb);

  const handleThumbError = () => {
    setThumbSrc(null); // fallback to placeholder
  };

  // ── Avatar handling ───────────────────────────
  const avatarSrc = course.creator?.image
    ? `${API_BASE}/uploads/avatars/${course.creator.image}`
    : `https://ui-avatars.com/api/?name=${encodeURIComponent(
        course.creator?.name || 'I'
      )}&size=24&background=4A90D9&color=fff`;

  const [creatorImg, setCreatorImg] = useState(avatarSrc);

  const handleAvatarError = () => {
    setCreatorImg(
      `https://ui-avatars.com/api/?name=${encodeURIComponent(
        course.creator?.name || 'I'
      )}&size=24&background=4A90D9&color=fff`
    );
  };

  const courseLink = `/courses/${course.slug || course.id}`;

  return (
    <div className="course-card">
      {/* ── Thumbnail ───────────────────────── */}
      <Link to={courseLink} style={{ textDecoration: 'none' }}>
        {thumbSrc ? (
          <img
            src={thumbSrc}
            alt={course.title}
            className="course-card-img"
            onError={handleThumbError}
          />
        ) : (
          <div className="course-card-img-placeholder">
            <i className="bi bi-play-circle" />
          </div>
        )}
      </Link>

      {/* ── Body ───────────────────────────── */}
      <div className="course-card-body">
        <div className="d-flex align-items-center gap-2 mb-2">
          <span className={`badge-level ${course.level}`}>
            {course.level}
          </span>

          {course.featured && (
            <span
              className="badge bg-warning text-dark"
              style={{ fontSize: '0.6rem' }}
            >
              Featured
            </span>
          )}
        </div>

        <Link to={courseLink} className="text-decoration-none">
          <h6 className="course-card-title truncate-2">
            {course.title}
          </h6>
        </Link>

        {course.short_description && (
          <p
            className="text-muted truncate-2"
            style={{ fontSize: '0.78rem', marginBottom: '0.5rem' }}
          >
            {course.short_description}
          </p>
        )}

        {/* ── Creator ───────────────────────── */}
        {course.creator && (
          <div className="d-flex align-items-center gap-2 mb-2">
            <img
              src={creatorImg}
              onError={handleAvatarError}
              alt={course.creator.name}
              style={{
                width: 20,
                height: 20,
                borderRadius: '50%',
                objectFit: 'cover',
              }}
            />
            <span
              style={{
                fontSize: '0.75rem',
                color: 'var(--text-muted)',
              }}
            >
              {course.creator.name}
            </span>
          </div>
        )}

        {/* ── Meta ─────────────────────────── */}
        <div className="course-card-meta">
          <span>
            <i className="bi bi-book me-1" />
            {course.lessons_count}
          </span>
          <span>
            <i className="bi bi-people me-1" />
            {course.enrolled_count}
          </span>
          {course.avg_rating && (
            <span>
              <i className="bi bi-star-fill me-1 text-warning" />
              {course.avg_rating}
            </span>
          )}
        </div>

        {/* ── Progress ─────────────────────── */}
        {course.is_enrolled && (
          <div className="mt-auto">
            <div
              className="d-flex justify-content-between mb-1"
              style={{ fontSize: '0.75rem' }}
            >
              <span className="text-muted">Progress</span>
              <span className="text-primary fw-600">
                {course.progress_pct}%
              </span>
            </div>
            <div className="progress">
              <div
                className="progress-bar"
                style={{ width: `${course.progress_pct}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* ── Footer ─────────────────────────── */}
      <div className="course-card-footer">
        <div>
          {course.fee > 0 ? (
            <span className="fw-700 text-primary">
              ₦{course.fee.toLocaleString()}
            </span>
          ) : (
            <span
              className="badge bg-success text-white"
              style={{ fontSize: '0.75rem' }}
            >
              Free
            </span>
          )}
        </div>

        {course.is_enrolled ? (
          <Link
            to={`/learn/${course.slug}`}
            className="btn btn-sm btn-primary btn-icon-start"
            style={{ borderRadius: 999 }}
          >
            <i className="bi bi-play-fill" /> Continue
          </Link>
        ) : (
          <Link
            to={courseLink}
            className="btn btn-sm btn-outline-primary"
            style={{ borderRadius: 999 }}
          >
            View
          </Link>
        )}
      </div>
    </div>
  );
}

// ── PAGE TITLE ───────────────────────────────────
export function PageTitle({ title, subtitle, crumbs }: {
  title: string; subtitle?: string; crumbs?: { label: string; href?: string }[];
}) {
  return (
    <div className="page-title-container">
      <div className="row align-items-center">
        <div className="col">
          <h1 className="mb-1">{title}</h1>
          {subtitle && <p className="text-muted mb-0" style={{ fontSize: '0.875rem' }}>{subtitle}</p>}
          {crumbs && (
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb pt-1 mb-0">
                {crumbs.map((c, i) => (
                  <li key={i} className={`breadcrumb-item ${i === crumbs.length - 1 ? 'active' : ''}`}>
                    {c.href && i < crumbs.length - 1 ? <a href={c.href}>{c.label}</a> : c.label}
                  </li>
                ))}
              </ol>
            </nav>
          )}
        </div>
      </div>
    </div>
  );
}

// ── MODAL ────────────────────────────────────────
export function Modal({ show, onClose, title, children, size = 'md', footer }: {
  show: boolean; onClose: () => void; title: string; children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl'; footer?: React.ReactNode;
}) {
  if (!show) return null;
  return (
    <>
      <div className="modal-backdrop fade show" style={{ zIndex: 1040 }} onClick={onClose} />
      <div className="modal fade show d-block" style={{ zIndex: 1050 }} tabIndex={-1}>
        <div className={`modal-dialog modal-${size} modal-dialog-centered modal-dialog-scrollable`}>
          <div className="modal-content" style={{ borderRadius: 'var(--radius-lg)', border: 'none', boxShadow: 'var(--shadow-lg)' }}>
            <div className="modal-header border-bottom" style={{ padding: '1.25rem 1.5rem' }}>
              <h5 className="modal-title fw-700">{title}</h5>
              <button type="button" className="btn-close" onClick={onClose} />
            </div>
            <div className="modal-body" style={{ padding: '1.5rem' }}>{children}</div>
            {footer && <div className="modal-footer border-top" style={{ padding: '1rem 1.5rem' }}>{footer}</div>}
          </div>
        </div>
      </div>
    </>
  );
}

// ── BADGE STATUS ─────────────────────────────────
export function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    published: 'success', active: 'success', approved: 'success', completed: 'success', issued: 'success',
    pending: 'warning', draft: 'secondary', unpublished: 'secondary', suspended: 'warning',
    rejected: 'danger', failed: 'danger', terminated: 'danger',
  };
  return <span className={`badge bg-${colors[status] || 'secondary'}`} style={{ textTransform: 'capitalize', fontSize: '0.7rem' }}>{status}</span>;
}

// ── CERTIFICATE CARD ─────────────────────────────
export function CertCard({ cert }: { cert: Certificate }) {
  return (
    <div className="certificate-card">
      <div className="text-primary mb-2" style={{ fontSize: '2.5rem' }}>
        <i className="bi bi-award-fill" />
      </div>
      <h6 className="fw-700 mb-1">{cert.course?.title || 'Course Completion'}</h6>
      <p className="text-muted mb-2" style={{ fontSize: '0.8rem' }}>Certificate No: {cert.cert_number}</p>
      <p className="text-muted mb-3" style={{ fontSize: '0.75rem' }}>Issued: {new Date(cert.issued_at).toLocaleDateString()}</p>
      <div className="d-flex gap-2 justify-content-center">
        {cert.cert_url && (
          <a href={`/api/v1/certificates/${cert.id}/download`} target="_blank" rel="noreferrer" className="btn btn-sm btn-primary btn-icon-start">
            <i className="bi bi-download" /> Download
          </a>
        )}
        <button className="btn btn-sm btn-outline-secondary btn-icon-start">
          <i className="bi bi-share" /> Share
        </button>
      </div>
    </div>
  );
}

// ── SEARCH INPUT ──────────────────────────────────
export function SearchInput({ value, onChange, placeholder = 'Search…' }: {
  value: string; onChange: (v: string) => void; placeholder?: string;
}) {
  return (
    <div className="position-relative">
      <i className="bi bi-search position-absolute" style={{ left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', zIndex: 2 }} />
      <input
        type="text" value={value} onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="form-control" style={{ paddingLeft: '2.25rem', borderRadius: 999 }}
      />
    </div>
  );
}

// ── RATING STARS ──────────────────────────────────
export function RatingStars({ rating, max = 5 }: { rating: number; max?: number }) {
  return (
    <span className="d-inline-flex gap-1" style={{ color: '#f0ad4e' }}>
      {Array.from({ length: max }).map((_, i) => (
        <i key={i} className={`bi ${i < Math.floor(rating) ? 'bi-star-fill' : i < rating ? 'bi-star-half' : 'bi-star'}`} style={{ fontSize: '0.8rem' }} />
      ))}
    </span>
  );
}

// ── AVATAR ────────────────────────────────────────
// export function Avatar({ image, name, size = 40 }: { image?: string; name?: string; size?: number }) {
//   const src = image && image !== 'default.svg'
//     ? `/uploads/avatars/${image}`
//     : `https://ui-avatars.com/api/?name=${encodeURIComponent(name || 'U')}&size=${size * 2}&background=4A90D9&color=fff`;
//   return <img src={src} alt={name || ''} style={{ width: size, height: size, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }} />;
// }
// v2 with error handling


export function Avatar({
  image,
  name,
  size = 40,
  onClick,
  className = '',
}: {
  image?: string;
  name?: string;
  size?: number;
  onClick?: React.MouseEventHandler<HTMLImageElement>;
  className?: string;
}) {
  // ── Fallback generator ───────────────────────
  const fallback = useMemo(
    () =>
      `https://ui-avatars.com/api/?name=${encodeURIComponent(
        name || 'U'
      )}&size=${size * 2}&background=4A90D9&color=fff`,
    [name, size]
  );

  // ── Initial src ─────────────────────────────
  const initialSrc =
    image && image !== 'default.svg'
      ? `${API_BASE}/uploads/avatars/${image}`
      : fallback;

  const [src, setSrc] = useState(initialSrc);

  // ── Handle broken image ─────────────────────
  const handleError = () => {
    if (src !== fallback) {
      setSrc(fallback);
    }
  };

  return (
    <img
      src={src}
      onError={handleError}
      onClick={onClick}
      alt={name || 'User avatar'}
      className={className}
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        objectFit: 'cover',
        flexShrink: 0,
        cursor: onClick ? 'pointer' : undefined,
      }}
    />
  );
}
