// src/components/shared/CourseThumbnail.tsx
import { useState } from 'react';

interface CourseThumbnailProps {
  thumbnail?: string | null;
  size?: number;
  aspectRatio?: number;  // height / width, default 0.75 (52/72, 36/48)
  borderRadius?: number;
  className?: string;
}

export function CourseThumbnail({ 
  thumbnail, 
  size = 72, 
  aspectRatio = 0.75,
  borderRadius = 8,
  className = ''
}: CourseThumbnailProps) {
  const [error, setError] = useState(false);

  const width = size;
  const height = size * aspectRatio;

  if (!thumbnail || error) {
    return (
      <div 
        className={className}
        style={{ 
          width, 
          height, 
          borderRadius, 
          background: 'var(--primary-light)', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center', 
          flexShrink: 0,
          overflow: 'hidden'
        }}
      >
        <i className="bi bi-play-circle text-primary" style={{ fontSize: `${width * 0.3}px` }} />
      </div>
    );
  }

  return (
    <img 
      src={`/uploads/courses/thumbnails/${thumbnail}`} 
      alt="" 
      onError={() => setError(true)}
      className={className}
      style={{ 
        width, 
        height, 
        borderRadius, 
        objectFit: 'cover', 
        flexShrink: 0,
        display: 'block'
      }} 
    />
  );
}